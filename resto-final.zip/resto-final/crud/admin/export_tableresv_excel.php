<?php
// Ambil koneksi database
date_default_timezone_set('Asia/Jakarta');
$db = include 'koneksi.php';

// Ambil parameter dari GET
$rawSearch  = isset($_GET['search']) ? $_GET['search'] : '';
$search     = "%" . $rawSearch . "%";
$startDate  = isset($_GET['start_date']) ? $_GET['start_date'] : '';
$endDate    = isset($_GET['end_date']) ? $_GET['end_date'] : '';

// Query data sesuai filter
$sql = "SELECT * FROM table_reservations
        WHERE (
            name LIKE :search
            OR phone LIKE :search
            OR transaction_code LIKE :search
        )";

if (!empty($startDate) && !empty($endDate)) {
    $sql .= " AND DATE(reservation_datetime) BETWEEN :startDate AND :endDate";
}

$sql .= " ORDER BY reservation_datetime DESC";

$stmt = $db->prepare($sql);
$stmt->bindValue(':search', $search, PDO::PARAM_STR);
if (!empty($startDate) && !empty($endDate)) {
    $stmt->bindValue(':startDate', $startDate, PDO::PARAM_STR);
    $stmt->bindValue(':endDate', $endDate, PDO::PARAM_STR);
}
$stmt->execute();
$reservations = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Set header agar browser mengenali ini sebagai file Excel
$exportDate = date('Y-m-d_H-i');
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=report_table_reservations_{$exportDate}.xls");
header("Pragma: no-cache");
header("Expires: 0");

// Output data sebagai tabel HTML (dibaca oleh Excel)
echo "<table border='1'>";
echo "<tr>
        <th>No</th>
        <th>Reservation Date & Time</th>
        <th>Customer Name</th>
        <th>Phone Number</th>
        <th>Number of People</th>
        <th>Total Payment</th>
        <th>Status</th>
        <th>Midtrans Order ID</th>
      </tr>";

$no = 1;
foreach ($reservations as $row) {
    $datetime = htmlspecialchars(date('d M Y H:i', strtotime($row['reservation_datetime'])));
    $name     = htmlspecialchars($row['name']);
    $phone    = htmlspecialchars($row['phone']);
    $people   = htmlspecialchars($row['number_of_people']);
    $price    = number_format($row['price'], 0, ',', '.');
    $status   = htmlspecialchars(ucwords($row['status']));
    $trxCode  = htmlspecialchars($row['transaction_code']);

    echo "<tr>
            <td>{$no}</td>
            <td>{$datetime}</td>
            <td>{$name}</td>
            <td>{$phone}</td>
            <td>{$people}</td>
            <td>Rp {$price}</td>
            <td>{$status}</td>
            <td>{$trxCode}</td>
          </tr>";
    $no++;
}

echo "</table>";
exit;
