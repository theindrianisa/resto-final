<?php
// Ambil koneksi database
date_default_timezone_set('Asia/Jakarta');
$db = include 'koneksi.php';

// Ambil parameter dari GET
$rawSearch  = isset($_GET['search']) ? $_GET['search'] : '';
$search     = "%" . $rawSearch . "%";
$startDate  = isset($_GET['start_date']) ? $_GET['start_date'] : '';
$endDate    = isset($_GET['end_date']) ? $_GET['end_date'] : '';

// Query data delivery orders
$sql = "SELECT order_date, order_time, customer_name, phone, address, payment_amount, payment_method, status, midtrans_order_id
        FROM delivery_orders
        WHERE (
            customer_name LIKE :search
            OR phone LIKE :search
            OR address LIKE :search
            OR midtrans_order_id LIKE :search
        )";

if (!empty($startDate) && !empty($endDate)) {
    $sql .= " AND DATE(order_date) BETWEEN :startDate AND :endDate";
}

$sql .= " ORDER BY order_date DESC, order_time DESC";

$stmt = $db->prepare($sql);
$stmt->bindValue(':search', $search, PDO::PARAM_STR);
if (!empty($startDate) && !empty($endDate)) {
    $stmt->bindValue(':startDate', $startDate, PDO::PARAM_STR);
    $stmt->bindValue(':endDate', $endDate, PDO::PARAM_STR);
}
$stmt->execute();
$orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Set header agar browser mengenali ini sebagai file Excel
$exportDate = date('Y-m-d_H-i');
header("Content-Type: application/vnd.ms-excel");
header("Content-Disposition: attachment; filename=report_delivery_sales_{$exportDate}.xls");
header("Pragma: no-cache");
header("Expires: 0");

// Output data sebagai tabel HTML (dibaca oleh Excel)
echo "<table border='1'>";
echo "<tr>
        <th>No</th>
        <th>Order Date & Time</th>
        <th>Customer Name</th>
        <th>Phone Number</th>
        <th>Address</th>
        <th>Total Payment</th>
        <th>Payment Method</th>
        <th>Status</th>
        <th>Midtrans Order ID</th>
      </tr>";

$no = 1;
foreach ($orders as $row) {
    $datetime = htmlspecialchars(date('d M Y', strtotime($row['order_date'])) . ' ' . $row['order_time']);
    $nama     = htmlspecialchars($row['customer_name']);
    $noHP     = htmlspecialchars($row['phone']);
    $alamat   = htmlspecialchars($row['address']);
    $total    = number_format($row['payment_amount'], 0, ',', '.');
    $metode   = htmlspecialchars($row['payment_method']);
    $status   = htmlspecialchars(ucwords($row['status']));
    $orderID  = htmlspecialchars($row['midtrans_order_id']);

    echo "<tr>
            <td>{$no}</td>
            <td>{$datetime}</td>
            <td>{$nama}</td>
            <td>{$noHP}</td>
            <td>{$alamat}</td>
            <td>Rp {$total}</td>
            <td>{$metode}</td>
            <td>{$status}</td>
            <td>{$orderID}</td>
          </tr>";
    $no++;
}

echo "</table>";
exit;
