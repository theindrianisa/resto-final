<?php 
$db = require_once("koneksi.php");
session_start();

$error = '';

if(isset($_POST['login'])) {
    $username = trim($_POST['username']);
$password = trim($_POST['password']);

    $sql = "SELECT * FROM users WHERE username = :username OR email = :email";
    $stmt = $db->prepare($sql);

    $params = [
        ":username" => $username,
        ":email" => $username
    ];

    $stmt->execute($params);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if($user) {
        if(password_verify($password, $user["password"])) {
            $_SESSION["user"] = $user;
            header("Location: index.php");
            exit;
        } else {
            $error = "Password salah!";
        }
    } else {
        $error = "Username atau email tidak ditemukan!";
    }
}
?>

<!DOCTYPE html>
<html lang="en" class="light-style customizer-hide" dir="ltr" data-theme="theme-default" data-assets-path="../../dash/assets/" data-template="vertical-menu-template-free">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Login</title>
  <link rel="shortcut icon" href="../../img/hero.PNG"> 
  <link rel="stylesheet" href="../../dash/assets/vendor/fonts/boxicons.css" />
  <link rel="stylesheet" href="../../dash/assets/vendor/css/core.css" />
  <link rel="stylesheet" href="../../dash/assets/vendor/css/theme-default.css" />
  <link rel="stylesheet" href="../../dash/assets/css/demo.css" />
  <link rel="stylesheet" href="../../dash/assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.css" />
  <link rel="stylesheet" href="../../dash/assets/vendor/css/pages/page-auth.css" />
  <script src="../../dash/assets/vendor/js/helpers.js"></script>
  <script src="../../dash/assets/js/config.js"></script>
</head>

<body>
  <div class="container-xxl">
    <div class="authentication-wrapper authentication-basic container-p-y">
      <div class="authentication-inner">
        <div class="card">
          <div class="card-body">
            <div class="app-brand justify-content-center">
              <span class="app-brand-logo demo">
                <img src="../../img/hero.PNG" alt="" style="width: 60px;">
              </span>
            </div>
            <h4 class="mb-2">Welcome to Ocean's Feast! 👋</h4>
            <p class="mb-4">Please sign-in to your account and order your food</p>

            <?php if ($error): ?>
              <div class="alert alert-danger"><?= htmlspecialchars($error) ?></div>
            <?php endif; ?>

            <form id="formAuthentication" class="mb-3" action="" method="POST">
              <div class="mb-3">
                <label for="username" class="form-label">Username / Email</label>
                <input type="text" class="form-control" id="username" name="username" placeholder="Enter your username or email" autofocus required />
              </div>

              <div class="mb-3 form-password-toggle">
                <label class="form-label" for="password">Password</label>
                <div class="input-group input-group-merge">
                  <input type="password" id="password" class="form-control" name="password" placeholder="••••••••••••" required />
                  <span class="input-group-text cursor-pointer"><i class="bx bx-hide"></i></span>
                </div>
              </div>

              <div class="mb-3">
                <div class="form-check">
                  <input class="form-check-input" type="checkbox" id="remember-me" />
                  <label class="form-check-label" for="remember-me">Remember Me</label>
                </div>
              </div>

              <div class="mb-3">
                <button class="btn btn-primary d-grid w-100" type="submit" name="login">Sign in</button>
              </div>
            </form>

            <p class="text-center">
              <span>Forgot your password? <br> Please contact the administrator</span>
            </p>
          </div>
        </div>
      </div>
    </div>
  </div>

  <script src="../../dash/assets/vendor/libs/jquery/jquery.js"></script>
  <script src="../../dash/assets/vendor/libs/popper/popper.js"></script>
  <script src="../../dash/assets/vendor/js/bootstrap.js"></script>
  <script src="../../dash/assets/vendor/libs/perfect-scrollbar/perfect-scrollbar.js"></script>
  <script src="../../dash/assets/vendor/js/menu.js"></script>
  <script src="../../dash/assets/js/main.js"></script>
</body>
</html>
