<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$conn = require_once 'koneksi.php';

// === PHPMailer ===
require_once 'PHPMailer-master/src/PHPMailer.php';
require_once 'PHPMailer-master/src/SMTP.php';
require_once 'PHPMailer-master/src/Exception.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// === Midtrans ===
require_once 'Midtrans/Config.php';
require_once 'Midtrans/Sanitizer.php';
require_once 'Midtrans/Notification.php';
require_once 'Midtrans/Transaction.php';
require_once 'Midtrans/ApiRequestor.php';
require_once 'Midtrans/SnapApiRequestor.php';
require_once 'Midtrans/Snap.php';

use Midtrans\Snap;
use Midtrans\Config;

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    try {
        // Ambil data reservasi
        $stmt = $conn->prepare("SELECT name, email, price FROM table_reservations WHERE id = ?");
        $stmt->execute([$id]);
        $reservation = $stmt->fetch(PDO::FETCH_ASSOC);

        if (!$reservation) {
            die("Reservation not found");
        }

        $name  = $reservation['name'];
        $email = $reservation['email'];
        $price = (int)($reservation['price'] ?? 0);

        if ($price <= 0) {
            throw new Exception("Invalid reservation price.");
        }

        // 1. Buat order_id untuk Midtrans
        $order_id = 'RESV-' . strtoupper(uniqid());

        // 2. Generate URL QR Code dari transaction_code (yaitu order_id ini)
        $qrUrl = 'https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=' . urlencode($order_id);


        // 3. Update status, transaction_code, dan QR Code ke database
        $stmt = $conn->prepare("UPDATE table_reservations SET status = 'approved', transaction_code = ?, transaction_id = NULL, qr_code = ? WHERE id = ?");
        $stmt->execute([$order_id, $qrUrl, $id]);

        // 4. Midtrans config
        Config::$serverKey = 'SB-Mid-server-s1oBo3NDiosQdRHxInkxVYdN';
        Config::$isProduction = false;
        Config::$isSanitized = true;
        Config::$is3ds = true;

        $params = [
            'transaction_details' => [
                'order_id' => $order_id,
                'gross_amount' => $price,
            ],
            'customer_details' => [
                'first_name' => $name,
                'email' => $email,
            ]
        ];

        // 5. Buat Snap URL dari Midtrans
        $transaction = Snap::createTransaction($params);
        $snapUrl = $transaction->redirect_url;

        // 6. Kirim email
        $mail = new PHPMailer(true);
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'anisa.indriani@widyatama.ac.id';
        $mail->Password   = 'smczlewnlvhjibid';
        $mail->SMTPSecure = 'tls';
        $mail->Port       = 587;

        $mail->setFrom('anisa.indriani@widyatama.ac.id', 'Resto Management');
        $mail->addAddress($email, $name);

        $mail->isHTML(true);
        $mail->Subject = 'Reservation Approved - Please Proceed to Payment';
        $mail->Body    = "
            <html>
            <body>
              <p>Dear <strong>$name</strong>,</p>
              <p>Your reservation has been <strong>approved</strong>.</p>
              <p>Please complete your payment using the link below:</p>
              <p><a href='$snapUrl' target='_blank'>Click here to pay</a></p>
              <br>
              <p>Thank you,<br>Resto Management</p>
            </body>
            </html>
        ";

        $mail->send();

        header("Location: table_reservations.php?message=approved");
        exit;

    } catch (Exception $e) {
        echo "Email or Snap error: " . $e->getMessage();
    } catch (PDOException $e) {
        echo "Database error: " . $e->getMessage();
    }
} else {
    header("Location: table_reservations.php?message=invalid");
    exit;
}
