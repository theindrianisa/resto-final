<?php
// File: midtrans_notification.php
require_once 'koneksi.php';

require_once 'Midtrans/Config.php';
require_once 'Midtrans/Sanitizer.php';
require_once 'Midtrans/Notification.php';
require_once 'Midtrans/Transaction.php';
require_once 'Midtrans/ApiRequestor.php';
require_once 'Midtrans/Snap.php';

use Midtrans\Config;
use Midtrans\Notification;

Config::$serverKey = 'SB-Mid-server-s1oBo3NDiosQdRHxInkxVYdN'; // GANTI jika perlu
Config::$isProduction = false;

try {
    $notif = new Notification();

    $transaction = $notif->transaction_status;
    $order_id = $notif->order_id;         // contoh: RESV-64D2A7BC0E3B9
    $gross_amount = $notif->gross_amount;

    if ($transaction == 'settlement') {
        // Update payment_status jadi Paid
        $stmt = $conn->prepare("UPDATE table_reservations SET payment_status = 'Paid', price = ?, transaction_id = ? WHERE transaction_id = ?");
        $stmt->execute([$gross_amount, $order_id, $order_id]);
    }

    http_response_code(200);
    echo "OK";

} catch (Exception $e) {
    http_response_code(500);
    echo "Notification error: " . $e->getMessage();
}
