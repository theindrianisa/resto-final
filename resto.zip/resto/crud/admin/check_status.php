<?php
// Include semua file Midtrans dari folder manual (tanpa composer)
require_once __DIR__ . '/midtrans/Config.php';
require_once __DIR__ . '/midtrans/Snap.php';
require_once __DIR__ . '/midtrans/Transaction.php';
require_once __DIR__ . '/midtrans/Notification.php';
require_once __DIR__ . '/midtrans/Sanitizer.php';
require_once __DIR__ . '/midtrans/CoreApi.php';
require_once __DIR__ . '/midtrans/ApiRequestor.php';
require_once __DIR__ . '/midtrans/SnapApiRequestor.php';

// Set konfigurasi Midtrans
\Midtrans\Config::$serverKey = 'SB-Mid-server-s1oBo3NDiosQdRHxInkxVYdN'; // Ganti dengan server key kamu
\Midtrans\Config::$isProduction = false; // false untuk sandbox, true untuk production

// Cek status transaksi berdasarkan order_id
try {
    $status = \Midtrans\Transaction::status('RESV-68328D95027E4');
    echo "<pre>";
    print_r($status);
    echo "</pre>";
} catch (Exception $e) {
    echo "Gagal mengambil status transaksi: " . $e->getMessage();
}
