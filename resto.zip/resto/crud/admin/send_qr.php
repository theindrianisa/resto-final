<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

$db = include 'koneksi.php';

// PHPMailer
require_once 'PHPMailer-master/src/PHPMailer.php';
require_once 'PHPMailer-master/src/SMTP.php';
require_once 'PHPMailer-master/src/Exception.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if (!isset($_GET['id'])) {
    header("Location: table_reservations.php?message=invalid");
    exit();
}

$id = $_GET['id'];

// Ambil data reservasi
$stmt = $db->prepare("SELECT name, email, qr_code FROM table_reservations WHERE id = ?");
$stmt->execute([$id]);
$reservation = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$reservation || empty($reservation['qr_code'])) {
    header("Location: table_reservations.php?message=invalid");
    exit();
}

$name    = $reservation['name'];
$email   = $reservation['email'];
$qrImage = $reservation['qr_code']; // Ini berupa URL langsung ke QR code

try {
    $mail = new PHPMailer(true);
    $mail->isSMTP();
    $mail->Host       = 'smtp.gmail.com';
    $mail->SMTPAuth   = true;
    $mail->Username   = 'anisa.indriani@widyatama.ac.id'; // ganti sesuai
    $mail->Password   = 'smczlewnlvhjibid'; // ganti sesuai
    $mail->SMTPSecure = 'tls';
    $mail->Port       = 587;

    $mail->setFrom('anisa.indriani@widyatama.ac.id', 'Resto Management');
    $mail->addAddress($email, $name);

    $mail->isHTML(true);
    $mail->Subject = 'QR Code for Your Reservation';

    $mail->Body = "
        <html>
        <body>
            <p>Dear <strong>$name</strong>,</p>
            <p>Thank you for your payment. Below is your reservation QR Code:</p>
            <p><img src='" . htmlspecialchars($qrImage, ENT_QUOTES) . "' alt='QR Code' style='max-width:250px;'></p>
            <p>Please show this QR code upon arrival at the restaurant.</p>
            <br>
            <p>Warm regards,<br><strong>Ocean's Feast</strong></p>
        </body>
        </html>
    ";

    $mail->send();
    header("Location: table_reservations.php?message=sent");
    exit();

} catch (Exception $e) {
    echo "Email failed: " . $mail->ErrorInfo;
}
