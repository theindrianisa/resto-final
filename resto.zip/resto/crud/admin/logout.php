<?php
session_start();

// Menghancurkan semua session
session_unset();
session_destroy();

// Redirect ke halaman login setelah logout
header("Location: login_admin.php");
exit;
?>
