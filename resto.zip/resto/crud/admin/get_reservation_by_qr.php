<?php
$db = include 'koneksi.php';

$code = $_GET['code'] ?? '';
if (!$code) {
  echo json_encode(['success' => false]);
  exit;
}

$stmt = $db->prepare("SELECT * FROM table_reservations WHERE transaction_code = ?");
$stmt->execute([$code]);
$row = $stmt->fetch(PDO::FETCH_ASSOC);

if ($row) {
    echo json_encode([
        'success' => true,
        'id' => $row['id'],
        'name' => $row['name'],
        'email' => $row['email'],
        'phone' => $row['phone'],
        'reservation_datetime' => $row['reservation_datetime'],
        'number_of_people' => $row['number_of_people'],
        'special_request' => $row['special_request'],
        'status' => $row['status'],
        'payment_status' => $row['payment_status'],
        // 'transaction_id' => $row['transaction_id'],
        'transaction_code' => $row['transaction_code']
    ]);
} else {
    echo json_encode(['success' => false]);
}
