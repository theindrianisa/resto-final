<?php
session_start();
require_once("koneksi.php");

// Error reporting aktif
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Ambil nama user dari session
$firstname = htmlspecialchars($_SESSION['firstname'] ?? 'Guest');

// Notifikasi sukses (misal dari checkout atau reservasi)
if (isset($_SESSION['success_message'])) {
    echo "
    <script>
        document.addEventListener('DOMContentLoaded', function () {
            Swal.fire({
                icon: 'success',
                title: 'Success!',
                text: '" . $_SESSION['success_message'] . "',
                confirmButtonText: 'OK'
            });
        });
    </script>
    ";
    unset($_SESSION['success_message']);
}

// === Reservasi & Email ===
require_once __DIR__ . '/../admin/PHPMailer-master/src/Exception.php';
require_once __DIR__ . '/../admin/PHPMailer-master/src/PHPMailer.php';
require_once __DIR__ . '/../admin/PHPMailer-master/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['name'], $_POST['email'], $_POST['datetime'])) {
    try {
        $name = $_POST['name'];
        $email = $_POST['email'];
        $phone = $_POST['phone'];
        $datetime = DateTime::createFromFormat('m/d/Y h:i A', $_POST['datetime']);
        if (!$datetime) {
            throw new Exception("Format tanggal tidak valid.");
        }
        $reservation_datetime = $datetime->format('Y-m-d H:i:s');
        $number_of_people = (int) $_POST['number_of_people'];
        $special_request = $_POST['message'];
        $price = $number_of_people * 20000;

        $stmt = $db->prepare("INSERT INTO table_reservations 
            (name, email, phone, reservation_datetime, number_of_people, price, special_request, status, payment_status, created_at) 
            VALUES (:name, :email, :phone, :reservation_datetime, :number_of_people, :price, :special_request, 'pending', 'unpaid', NOW())");

        $stmt->execute([
            ':name' => $name,
            ':email' => $email,
            ':phone' => $phone,
            ':reservation_datetime' => $reservation_datetime,
            ':number_of_people' => $number_of_people,
            ':price' => $price,
            ':special_request' => $special_request
        ]);

        // Kirim Email
        $mail = new PHPMailer(true);
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'anisa.indriani@widyatama.ac.id'; // Ganti dengan emailmu
        $mail->Password = 'smczlewnlvhjibid'; // Gunakan app password Gmail
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;

        $mail->setFrom('youremail@gmail.com', 'Resto Reservation'); // Ganti sesuai email pengirim
        $mail->addAddress($email, $name);
        $mail->isHTML(true);
        $mail->Subject = 'Your Reservation Has Been Received';
        $mail->Body = "
            <h3>Hi, $name!</h3>
            <p>Thank you for your reservation. We have received your request and it's now pending approval.</p>
            <h4>Reservation Details:</h4>
            <ul>
                <li><strong>Date & Time:</strong> $reservation_datetime</li>
                <li><strong>No. of People:</strong> $number_of_people</li>
                <li><strong>Special Request:</strong> $special_request</li>
            </ul>
            <p>You will receive a confirmation once your reservation is approved.</p>
            <br>
            <p>Regards, <br>Ocean's Feast Resto Management</p>
        ";

        $mail->send();
        header("Location: timeline.php?message=success_reservation");
        exit;

    } catch (Exception $e) {
        error_log("Error: " . $e->getMessage());
        header("Location: timeline.php?message=error");
        exit;
    }
}
?>

<!DOCTYPE html>

<head>
    <meta charset="utf-8">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">  
    <link rel="shortcut icon" href="../../img/hero.PNG">    
    <title>Ocean's Feast</title>
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="../../img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600&family=Nunito:wght@600;700;800&family=Pacifico&display=swap" rel="stylesheet">

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="../../lib/animate/animate.min.css" rel="stylesheet">
    <link href="../../lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="../../lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="../../css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="../../css/style.css" rel="stylesheet">
</head>

<body>
    <div class="container-xxl bg-white p-0">
        <!-- Spinner Start -->
        <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->


        <!-- Navbar & Hero Start -->
        <div class="container-xxl position-relative p-0">
            <nav class="navbar navbar-expand-lg navbar-dark bg-dark px-4 px-lg-5 py-3 py-lg-0">
                <a href="" class="navbar-brand p-0">
                    <h1 class="text-primary m-0"><i class="fa fa-utensils me-3"></i>Ocean's Feast</h1>
                    <!-- <img src="img/logo.png" alt="Logo"> -->
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                    <span class="fa fa-bars"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarCollapse">
                    <div class="navbar-nav ms-auto py-0 pe-4">
                        <a href="timeline.php" class="nav-item nav-link">Home</a>
                        <a href="about.php" class="nav-item nav-link">About</a>
                        <a href="service.php" class="nav-item nav-link">Service</a>
                        <a href="menu.php" class="nav-item nav-link">Menu</a>
                        <div class="nav-item dropdown">
                            <a href="#" class="nav-link dropdown-toggle active" data-bs-toggle="dropdown">Pages</a>
                            <div class="dropdown-menu m-0">
                                <a href="booking.php" class="dropdown-item active">Booking</a>
                                <a href="team.php" class="dropdown-item">Our Team</a>
                                <a href="testimonial.php" class="dropdown-item">Testimonial</a>
                            </div>
                        </div>
                        <a href="contact.php" class="nav-item nav-link">Contact</a>
                    </div>
                    <a href="logout.php" class="btn btn-primary py-2 px-4">Log Out</a>
                </div>
            </nav>

            <div class="container-xxl py-5 bg-dark hero-header mb-5">
                <div class="container text-center my-5 pt-5 pb-4">
                    <h1 class="display-3 text-white mb-3 animated slideInDown">Booking</h1>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb justify-content-center text-uppercase">
                            <li class="breadcrumb-item"><a href="#">Home</a></li>
                            <li class="breadcrumb-item"><a href="#">Pages</a></li>
                            <li class="breadcrumb-item text-white active" aria-current="page">Booking</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
        <!-- Navbar & Hero End -->


       <!-- Reservation Start -->
<div class="container-xxl py-5 px-0 wow fadeInUp" data-wow-delay="0.1s">
  <div class="row g-0">
    <!-- Video Section -->
    <div class="col-md-6">
      <div class="video">
        <button type="button" class="btn-play" data-bs-toggle="modal" data-src="https://www.youtube.com/embed/DWRcNpR6Kdc" data-bs-target="#videoModal">
          <span></span>
        </button>
      </div>
    </div>

    <!-- Reservation Form -->
    <div class="col-md-6 bg-dark d-flex align-items-center">
      <div class="p-5 wow fadeInUp" data-wow-delay="0.2s">
        <h5 class="section-title ff-secondary text-start text-primary fw-normal">Reservation</h5>
        <h1 class="text-white mb-4">Book A Table Online</h1>
        
        <form action="timeline.php" method="POST">
          <div class="row g-3">
            <!-- Name -->
            <div class="col-md-6">
              <div class="form-floating">
                <input type="text" class="form-control" id="name" name="name" placeholder="Your Name" required>
                <label for="name">Your Name</label>
              </div>
            </div>

            <!-- Email -->
            <div class="col-md-6">
              <div class="form-floating">
                <input type="email" class="form-control" id="email" name="email" placeholder="Your Email" required>
                <label for="email">Your Email</label>
              </div>
            </div>

            <!-- Phone -->
            <div class="col-md-6">
              <div class="form-floating">
                <input type="text" class="form-control" id="phone" name="phone" placeholder="Your Phone"
                       pattern="^\+?\d{8,15}$"
                       title="Enter a valid phone number with digits and optional +" required>
                <label for="phone">Your Phone</label>
              </div>
            </div>

            <!-- Number of People -->
            <div class="col-md-6">
              <div class="form-floating">
                <input type="number" class="form-control" id="number_of_people" name="number_of_people"
                       placeholder="Number of People" min="1" max="10" required>
                <label for="number_of_people">No Of People</label>
              </div>
            </div>

            <!-- Date & Time -->
            <div class="col-md-12">
              <div class="form-floating date" id="date3" data-target-input="nearest">
                <input type="text" class="form-control datetimepicker-input" id="datetime" name="datetime"
                       placeholder="Date & Time" data-target="#date3" data-toggle="datetimepicker" required>
                <label for="datetime">Date & Time</label>
              </div>
            </div>

            <!-- Message -->
            <div class="col-12">
              <div class="form-floating">
                <textarea class="form-control" placeholder="Special Request" id="message" name="message" style="height: 100px"></textarea>
                <label for="message">Special Request</label>
              </div>
            </div>

            <!-- Submit -->
            <div class="col-12">
              <button class="btn btn-primary w-100 py-3" type="submit">Book Now</button>
            </div>
          </div>
        </form>
        
      </div>
    </div>
  </div>
</div>
<!-- Reservation End -->

<!-- Video Modal Start -->
<div class="modal fade" id="videoModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content rounded-0">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Youtube Video</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <div class="ratio ratio-16x9">
          <iframe class="embed-responsive-item" src="" id="video" allowfullscreen allowscriptaccess="always" allow="autoplay"></iframe>
        </div>
      </div>
    </div>
  </div>
</div>
<!-- Video Modal End -->

        

       <!-- Footer Start -->
       <div class="container-fluid bg-dark text-light footer pt-5 mt-5 wow fadeIn" data-wow-delay="0.1s">
        <div class="container py-5">
             <div class="row g-5">
                 <div class="col-lg-3 col-md-6">
                     <h4 class="section-title ff-secondary text-start text-primary fw-normal mb-4">Company</h4>
                     <a class="btn btn-link" href="#">About Us</a>
                     <a class="btn btn-link" href="https://api.whatsapp.com/qr/EXGON2CIPGQMK1?autoload=1&app_absent=0">Contact Us</a>
                     <a class="btn btn-link" href="booking.php">Reservation</a>
                 </div>
                 <div class="col-lg-3 col-md-6">
                     <h4 class="section-title ff-secondary text-start text-primary fw-normal mb-4">Contact</h4>
                     <p class="mb-2"><i class="fa fa-map-marker-alt me-3"></i>Bikini Bottom</p>
                     <p class="mb-2"><i class="fa fa-phone-alt me-3"></i>+012 345 67890</p>
                     <p class="mb-2"><i class="fa fa-envelope me-3"></i>krustycrab@gmail.com</p>
                 </div>
                 <div class="col-lg-3 col-md-6">
                     <h4 class="section-title ff-secondary text-start text-primary fw-normal mb-4">Opening</h4>
                     <h5 class="text-light fw-normal">Monday - Saturday</h5>
                     <p>09AM - 09PM</p>
                     <h5 class="text-light fw-normal">Sunday</h5>
                     <p>10AM - 08PM</p>
                 </div>
                 <div class="col-lg-3 col-md-6">
                     <h4 class="section-title ff-secondary text-start text-primary fw-normal mb-4">Newsletter</h4>
                     <p>Happy Meal, Happy Day.</p>
                 </div>
             </div>
         </div>
         <div class="container">
             <div class="copyright">
                 <div class="row">
                     <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
                         &copy; <a class="border-bottom" href="#">Nivia & Anisa</a> 
                         
                         <!--/*** This template is free as long as you keep the footer author’s credit link/attribution link/backlink. If you'd like to use the template without the footer author’s credit link/attribution link/backlink, you can purchase the Credit Removal License from "https://phpcodex.com/credit-removal". Thank you for your support. ***/-->
                         Designed By <a class="border-bottom" href="https://phpcodex.com">php Codex</a><br><br>
                         Distributed By <a class="border-bottom" href="https://themewagon.com" target="_blank">ThemeWagon</a>
                     </div>
                     <div class="col-md-6 text-center text-md-end">
                         <div class="footer-menu">
                             <a href="https://www.instagram.com/nivianurkh">Instagram Nivia</a>
                             <a href="https://www.instagram.com/heyitsshanin">Instagram Anisa</a>
                             <a href="https://api.whatsapp.com/qr/EXGON2CIPGQMK1?autoload=1&app_absent=0">WhatsApp Nivia</a>
                             <a href="">WhatsApp Anisa</a>
                         </div>
                     </div>
                 </div>
             </div>
         </div>
     </div>
     <!-- Footer End -->


        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

<!-- JavaScript Libraries -->
<script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
<script src="../../lib/wow/wow.min.js"></script>
<script src="../../lib/easing/easing.min.js"></script>
<script src="../../lib/waypoints/waypoints.min.js"></script>
<script src="../../lib/counterup/counterup.min.js"></script>
<script src="../../lib/owlcarousel/owl.carousel.min.js"></script>
<script src="../../lib/tempusdominus/js/moment.min.js"></script>
<script src="../../lib/tempusdominus/js/moment-timezone.min.js"></script>
<script src="../../lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

<!-- Template Javascript -->
<script src="../../js/main.js"></script>
</body>

</html>