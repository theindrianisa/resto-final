-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 22 Jun 2025 pada 17.49
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `resto`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `delivery_orders`
--

CREATE TABLE `delivery_orders` (
  `id` int(11) NOT NULL,
  `id_pelanggan` int(16) NOT NULL,
  `customer_name` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `address` text NOT NULL,
  `additional_information` text DEFAULT NULL,
  `latitude` varchar(50) DEFAULT NULL,
  `longitude` varchar(50) DEFAULT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `order_date` date DEFAULT curdate(),
  `order_time` time DEFAULT curtime(),
  `status` enum('Waiting for Payment','Being Prepared','Ready to Deliver','Out for Delivery','Delivered') NOT NULL DEFAULT 'Waiting for Payment',
  `midtrans_order_id` varchar(100) DEFAULT NULL,
  `payment_method` varchar(100) DEFAULT NULL,
  `payment_amount` decimal(10,2) DEFAULT NULL,
  `status_payment` enum('Unpaid','Paid','Failed') NOT NULL DEFAULT 'Unpaid'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `delivery_orders`
--

INSERT INTO `delivery_orders` (`id`, `id_pelanggan`, `customer_name`, `phone`, `address`, `additional_information`, `latitude`, `longitude`, `total_price`, `order_date`, `order_time`, `status`, `midtrans_order_id`, `payment_method`, `payment_amount`, `status_payment`) VALUES
(12, 1, 'Mees Hilgers', '081223179627', '22, Jalan Profesor Mochammad Yamin, RW 05, Menteng, Jakarta Pusat, Daerah Khusus Ibukota Jakarta, Jawa, 10310, Indonesia', 'Indonesia cintaku', '', '', 170000.00, '2025-06-12', '00:42:27', '', NULL, NULL, NULL, 'Unpaid'),
(13, 1, 'Mees Hilgers', '081223179627', '22, Jalan Profesor Mochammad Yamin, RW 05, Menteng, Jakarta Pusat, Daerah Khusus Ibukota Jakarta, Jawa, 10310, Indonesia', 'Indonesia cintaku', '', '', 170000.00, '2025-06-12', '00:43:39', '', NULL, NULL, NULL, 'Unpaid'),
(14, 1, 'Mees Hilgers', '081223179627', '22, Jalan Profesor Mochammad Yamin, RW 05, Menteng, Jakarta Pusat, Daerah Khusus Ibukota Jakarta, Jawa, 10310, Indonesia', 'Indonesia cintaku', '', '', 170000.00, '2025-06-12', '00:46:17', '', NULL, NULL, NULL, 'Unpaid'),
(15, 1, 'Mees Hilgers', '081223179627', '22, Jalan Profesor Mochammad Yamin, RW 05, Menteng, Jakarta Pusat, Daerah Khusus Ibukota Jakarta, Jawa, 10310, Indonesia', 'Indonesia cintaku', '', '', 170000.00, '2025-06-12', '00:46:59', '', NULL, NULL, NULL, 'Unpaid'),
(16, 1, 'Mees Hilgers', '081223179627', '22, Jalan Profesor Mochammad Yamin, RW 05, Menteng, Jakarta Pusat, Daerah Khusus Ibukota Jakarta, Jawa, 10310, Indonesia', 'Indonesia cintaku', '', '', 170000.00, '2025-06-12', '00:51:24', '', NULL, NULL, NULL, 'Unpaid'),
(17, 1, 'Mees Hilgers', '081223179627', '22, Jalan Profesor Mochammad Yamin, RW 05, Menteng, Jakarta Pusat, Daerah Khusus Ibukota Jakarta, Jawa, 10310, Indonesia', 'Indonesia cintaku', '', '', 170000.00, '2025-06-12', '00:55:52', '', NULL, NULL, NULL, 'Unpaid'),
(18, 1, 'Mees Hilgers', '081223179627', 'Jalan Widya Chandra VIII, RW 01, Senayan, Kebayoran Baru, Jakarta Selatan, Daerah Khusus Ibukota Jakarta, Jawa, 12190, Indonesia', 'loveee', '-6.229523089826145', '106.81347656092841', 195000.00, '2025-06-12', '00:57:23', '', NULL, NULL, NULL, 'Unpaid'),
(19, 1, 'Mees Hilgers', '081223179627', 'Jalan Widya Chandra IV, RW 01, Senayan, Kebayoran Baru, Jakarta Selatan, Daerah Khusus Ibukota Jakarta, Jawa, 12930, Indonesia', 'mees love nivia', '-6.226766054910005', '106.81411170880894', 50000.00, '2025-06-12', '01:05:49', '', NULL, NULL, NULL, 'Unpaid'),
(20, 1, 'Mees Hilgers', '081223179627', 'Jalan Robert Wolter Monginsidi, RW 01, Rawa Barat, Kebayoran Baru, Jakarta Selatan, Daerah Khusus Ibukota Jakarta, Jawa, 12170, Indonesia', 'hitooo', '-6.238908632005923', '106.81072997889716', 370000.00, '2025-06-12', '01:07:09', '', NULL, NULL, NULL, 'Unpaid'),
(21, 1, 'Mees Hilgers', '081223179627', 'Jalan Tulodong Bawah, RW 04, Selong, Kebayoran Baru, Jakarta Selatan, Daerah Khusus Ibukota Jakarta, Jawa, 12190, Indonesia', 'Hitoo', '-6.230546975314692', '106.81141662440497', 190000.00, '2025-06-12', '01:08:49', '', NULL, NULL, NULL, 'Unpaid'),
(22, 1, 'Mees Hilgers', '081223179627', 'Electronic City, Sudirman Central Business District Westway, RW 01, Senayan, Kebayoran Baru, Jakarta Selatan, Daerah Khusus Ibukota Jakarta, Jawa, 12190, Indonesia', 'Hito love Nivnivv', '-6.226254108728462', '106.81102180402378', 70000.00, '2025-06-12', '01:13:08', '', NULL, NULL, NULL, 'Unpaid'),
(23, 1, 'Mees Hilgers', '081223179627', 'Sudirman Central Business District Westway, RW 01, Senayan, Kebayoran Baru, Jakarta Selatan, Daerah Khusus Ibukota Jakarta, Jawa, 12190, Indonesia', 'Indonesiaa', '-6.226851379225077', '106.81153678815464', 558000.00, '2025-06-12', '01:21:36', '', NULL, NULL, NULL, 'Unpaid'),
(24, 1, 'Mees Hilgers', '081223179627', 'Electronic City, Sudirman Central Business District Westway, RW 01, Senayan, Kebayoran Baru, Jakarta Selatan, Daerah Khusus Ibukota Jakarta, Jawa, 12190, Indonesia', 'aaa', '-6.2263490310790806', '106.81193160853583', 525000.00, '2025-06-12', '01:22:35', '', NULL, NULL, NULL, 'Unpaid'),
(25, 1, 'Mees Hilgers', '081223179627', 'Lapangan Panahan, Jalan Gerbang Pemuda, RW 01, Gelora, Tanah Abang, Jakarta Pusat, Daerah Khusus Ibukota Jakarta, Jawa, 10270, Indonesia', 'mmm', '-6.215871092592146', '106.80163192591864', 380000.00, '2025-06-12', '01:23:59', '', NULL, NULL, NULL, 'Unpaid'),
(26, 1, 'Mees Hilgers', '081223179627', 'Sudirman Central Business District Westway, RW 01, Senayan, Kebayoran Baru, Jakarta Selatan, Daerah Khusus Ibukota Jakarta, Jawa, 12190, Indonesia', 'Rumahnya warna cream deket pos satpam', '-6.227179344432073', '106.81194019278338', 425000.00, '2025-06-21', '19:22:20', 'Waiting for Payment', 'DELIVERY-1749732165-9596', NULL, NULL, 'Unpaid'),
(27, 1, 'Mees Hilgers', '081223179627', 'Jalan Lingkar Stadion, RW 01, Gelora, Tanah Abang, Jakarta Pusat, Daerah Khusus Ibukota Jakarta, Jawa, 10270, Indonesia', 'Dekat gerbang 7', '-6.218860163713356', '106.80305671652606', 320000.00, '2025-06-12', '21:12:37', '', 'DELIVERY-1749745166-9424', NULL, NULL, 'Unpaid'),
(28, 1, 'Mees Hilgers', '081223179627', 'Jalan Lingkar Stadion, RW 01, Gelora, Tanah Abang, Jakarta Pusat, Daerah Khusus Ibukota Jakarta, Jawa, 10270, Indonesia', 'loveee', '-6.219284125146011', '106.80262756242884', 335000.00, '2025-06-20', '21:30:34', '', 'DELIVERY-1750434102-7152', NULL, NULL, 'Unpaid'),
(29, 1, 'Mees Hilgers', '081223179627', 'Prasasti Suharto, Jalan Medan Merdeka Selatan, RW 02, Gambir, Jakarta Pusat, Daerah Khusus Ibukota Jakarta, Jawa, 10110, Indonesia', 'kaka', '-6.1773022887171445', '106.82700347795618', 370000.00, '2025-06-20', '22:42:34', '', NULL, NULL, NULL, 'Unpaid'),
(30, 1, 'Mees Hilgers', '081223179627', 'Jalan Lingkar Stadion, RW 01, Gelora, Tanah Abang, Jakarta Pusat, Daerah Khusus Ibukota Jakarta, Jawa, 10270, Indonesia', 'ss', '-6.218772171675056', '106.80279922380579', 265000.00, '2025-06-20', '22:44:16', '', NULL, NULL, NULL, 'Unpaid'),
(31, 1, 'Mees Hilgers', '081223179627', 'Stadion Utama Gelora Bung Karno, Jalan Plaza Selatan, RW 01, Gelora, Tanah Abang, Jakarta Pusat, Daerah Khusus Ibukota Jakarta, Jawa, 10270, Indonesia', 'dd', '-6.21945477619222', '106.80262756242884', 70000.00, '2025-06-20', '22:45:55', '', NULL, NULL, NULL, 'Unpaid'),
(32, 1, 'Mees Hilgers', '081223179627', 'Jalan Lingkar Stadion, RW 01, Gelora, Tanah Abang, Jakarta Pusat, Daerah Khusus Ibukota Jakarta, Jawa, 10270, Indonesia', 'sss', '-6.2201715068567145', '106.80194091692103', 70000.00, '2025-06-20', '22:51:27', '', 'DELIVERY-1750434687-6436', NULL, NULL, 'Unpaid'),
(33, 1, 'Nivia', '081223179627', 'Jalan Lingkar Stadion, RW 01, Gelora, Tanah Abang, Jakarta Pusat, Daerah Khusus Ibukota Jakarta, Jawa, 10270, Indonesia', 'lovee', '-6.2189428228874295', '106.80262756242884', 310000.00, '2025-06-21', '00:16:36', '', 'DELIVERY-1750439796-3205', NULL, NULL, 'Unpaid'),
(34, 1, 'Nivia', '081223179627', 'Taman Ismail Marzuki, 73, Jalan Cikini Raya, RW 02, Cikini, Menteng, Jakarta Pusat, Daerah Khusus Ibukota Jakarta, Jawa, 10330, Indonesia', 'jjjs', '-6.188768695917652', '106.83984374161811', 670000.00, '2025-06-21', '05:27:33', '', 'DELIVERY-1750458453-8522', NULL, NULL, 'Unpaid'),
(35, 1, 'Nivia', '081223179627', 'Stadion Utama Gelora Bung Karno, Jalan Plaza Selatan, RW 01, Gelora, Tanah Abang, Jakarta Pusat, Daerah Khusus Ibukota Jakarta, Jawa, 10270, Indonesia', 'ss', '-6.21911347404441', '106.8031425465597', 120000.00, '2025-06-21', '05:59:24', '', 'DELIVERY-1750460364-7091', NULL, NULL, 'Unpaid'),
(36, 1, 'Nivia', '081223179627', 'Jalan Plaza Timur, RW 01, Gelora, Tanah Abang, Jakarta Pusat, Daerah Khusus Ibukota Jakarta, Jawa, 10270, Indonesia', 'sss', '-6.219284125146011', '106.80468749895228', 320000.00, '2025-06-21', '06:09:33', '', 'DELIVERY-1750460973-4643', NULL, NULL, 'Unpaid'),
(37, 1, 'Nivia', '081223179627', '21, Jalan Lembang, RW 05, Menteng, Jakarta Pusat, Daerah Khusus Ibukota Jakarta, Jawa, 10310, Indonesia', 'nanana', '-6.19795230866847', '106.83558654680384', 90000.00, '2025-06-21', '06:16:11', '', 'DELIVERY-1750461371-5934', NULL, NULL, 'Unpaid'),
(38, 1, 'Mees Hilgers', '081223179627', 'Stadion Utama Gelora Bung Karno, Jalan Plaza Selatan, RW 01, Gelora, Tanah Abang, Jakarta Pusat, Daerah Khusus Ibukota Jakarta, Jawa, 10270, Indonesia', 'bismillah', '-6.219120939510486', '106.80207824654646', 120000.00, '2025-06-21', '06:20:56', '', 'DELIVERY-1750461656-1964', NULL, NULL, 'Unpaid'),
(39, 1, 'Nivniv', '081223179627', 'Jalan Lingkar Stadion, RW 01, Gelora, Tanah Abang, Jakarta Pusat, Daerah Khusus Ibukota Jakarta, Jawa, 10270, Indonesia', 'pliss', '-6.218772171675056', '106.80262756242884', 195000.00, '2025-06-21', '07:01:38', '', 'DELIVERY-1750464098-4551', NULL, NULL, 'Unpaid'),
(40, 1, 'Nivniv', '081223179627', 'Paxel, Jalan Lingkar Stadion, RW 01, Gelora, Tanah Abang, Jakarta Pusat, Daerah Khusus Ibukota Jakarta, Jawa, 10270, Indonesia', 'pliss', '-6.218772171675056', '106.80365753069056', 185000.00, '2025-06-21', '07:12:56', 'Being Prepared', 'DELIVERY-1750464776-6625', NULL, NULL, 'Paid'),
(41, 1, 'Nivniv', '081223179627', 'Stadion Utama Gelora Bung Karno, Jalan Lingkar Stadion, RW 01, Gelora, Tanah Abang, Jakarta Pusat, Daerah Khusus Ibukota Jakarta, Jawa, 10270, Indonesia', 'Dekat gerbang', '-6.2184308690841705', '106.80334853968817', 508000.00, '2025-06-21', '11:18:52', 'Being Prepared', 'DELIVERY-1750479532-3182', NULL, NULL, 'Paid'),
(42, 1, 'Nivniv', '081223179627', 'Stadion Utama Gelora Bung Karno, Jalan Plaza Selatan, RW 01, Gelora, Tanah Abang, Jakarta Pusat, Daerah Khusus Ibukota Jakarta, Jawa, 10270, Indonesia', 'Dekat gerbang no 7 ya pa', '-6.218772171675056', '106.80334853968817', 340000.00, '2025-06-21', '11:26:13', 'Being Prepared', 'DELIVERY-1750479973-7310', NULL, NULL, 'Paid'),
(43, 5, 'Nivia', '081223179627', 'Jalan Lingkar Stadion, RW 01, Gelora, Tanah Abang, Jakarta Pusat, Daerah Khusus Ibukota Jakarta, Jawa, 10270, Indonesia', 'Dekat gerbang ya pa', '-6.21808956627174', '106.80300521693427', 190000.00, '2025-06-22', '22:22:47', 'Being Prepared', 'DELIVERY-1750605767-7136', NULL, NULL, 'Paid');

-- --------------------------------------------------------

--
-- Struktur dari tabel `delivery_order_items`
--

CREATE TABLE `delivery_order_items` (
  `id` int(11) NOT NULL,
  `delivery_id` int(11) DEFAULT NULL,
  `menu_id` int(11) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `delivery_order_items`
--

INSERT INTO `delivery_order_items` (`id`, `delivery_id`, `menu_id`, `quantity`, `price`) VALUES
(1, 28, 18, 1, 85000.00),
(2, 28, 19, 1, 250000.00),
(3, 32, 21, 1, 70000.00),
(4, 33, 21, 1, 70000.00),
(5, 33, 20, 2, 120000.00),
(6, 34, 19, 2, 250000.00),
(7, 34, 18, 2, 85000.00),
(8, 35, 20, 1, 120000.00),
(9, 36, 19, 1, 250000.00),
(10, 36, 21, 1, 70000.00),
(11, 37, 23, 1, 90000.00),
(12, 38, 20, 1, 120000.00),
(13, 39, 25, 1, 110000.00),
(14, 39, 24, 1, 85000.00),
(15, 40, 23, 1, 90000.00),
(16, 40, 22, 1, 95000.00),
(17, 41, 19, 1, 250000.00),
(18, 41, 20, 1, 120000.00),
(19, 41, 25, 1, 110000.00),
(20, 41, 45, 1, 28000.00),
(21, 42, 19, 1, 250000.00),
(22, 42, 28, 1, 30000.00),
(23, 42, 36, 1, 38000.00),
(24, 42, 44, 1, 22000.00),
(25, 43, 20, 1, 120000.00),
(26, 43, 21, 1, 70000.00);

-- --------------------------------------------------------

--
-- Struktur dari tabel `menu`
--

CREATE TABLE `menu` (
  `id` int(11) NOT NULL,
  `menu_name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(10,2) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `category` enum('Appetizer','Main Course','Dessert','Beverage') NOT NULL DEFAULT 'Main Course',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `menu_status` enum('Available','Unavailable') NOT NULL DEFAULT 'Available',
  `menu_code` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `menu`
--

INSERT INTO `menu` (`id`, `menu_name`, `description`, `price`, `image`, `category`, `created_at`, `updated_at`, `menu_status`, `menu_code`) VALUES
(18, 'Grilled Salmon', 'Fresh salmon grilled to perfection, served with lemon butter sauce', 85000.00, 'uploads/683c3462802df_68377477acdf0_Lemon Grilled Salmon.jpg', 'Main Course', '2025-06-01 11:07:14', '2025-06-01 11:07:14', 'Available', 'SLM001'),
(19, 'Lobster Thermidor', 'Classic lobster baked with creamy mustard sauce and cheese', 250000.00, 'uploads/683c34cc17d9f_683774cc64e5f_Lobster Thermidor.jpg', 'Main Course', '2025-06-01 11:09:00', '2025-06-01 11:09:00', 'Available', 'LOB004'),
(20, 'Seafood Paella', 'Traditional Spanish rice dish loaded with shrimp, mussels, and squid', 120000.00, 'uploads/683c35403dd8a_683774fd5626b_The Best Seafood Paella Recipe in 2025.jpg', 'Main Course', '2025-06-01 11:10:56', '2025-06-01 11:12:25', 'Available', 'PAE005'),
(21, 'Crispy Fish Tacos', 'Soft tortillas filled with crispy fried fish, cabbage slaw, and spicy mayo', 70000.00, 'uploads/683c358371a3a_6837753a30057_Crunchy Crispy Fish Tacos with Cilantro Lime Slaw Recipe.jpg', 'Main Course', '2025-06-01 11:12:03', '2025-06-01 11:12:03', 'Available', 'TAC010'),
(22, 'Blackened Tuna Steak', 'Seared tuna steak coated with Cajun spices, served with mango salsa', 95000.00, 'uploads/683c35ee7db14_68377fd3583ba_Grilled Tuna Steaks.jpg', 'Main Course', '2025-06-01 11:13:50', '2025-06-01 11:13:50', 'Available', 'TUN011'),
(23, 'Garlic Butter Shrimp Pasta', 'Pasta tossed with shrimp in garlic butter sauce and fresh herbs', 90000.00, 'uploads/683c3647be1ad_6837801de0eba_Garlic Butter Shrimp Pasta.jpg', 'Main Course', '2025-06-01 11:15:19', '2025-06-01 11:15:19', 'Available', 'SHR012'),
(24, 'Crab Cakes with Remoulade', 'Pan-fried crab cakes served with tangy remoulade sauce', 85000.00, 'uploads/683c369e6d1e4_68378058b6394_Crab Cakes with Remoulade Sauce.jpg', 'Main Course', '2025-06-01 11:16:46', '2025-06-01 11:16:46', 'Available', 'CRB013'),
(25, 'Steamed Sea Bass', 'Delicate sea bass steamed with ginger and soy, served with steamed vegetables', 110000.00, 'uploads/683c373bde0f0_683780aa0b560__Sun-Kissed Grilled Sea Bass.jpg', 'Main Course', '2025-06-01 11:19:23', '2025-06-01 11:19:23', 'Available', 'BAS014'),
(26, 'Spicy Calamari Rings', 'Crispy fried calamari rings tossed in spicy chili sauce', 45000.00, 'uploads/683c542fea8ba_Fried Calamari.jpg', 'Appetizer', '2025-06-01 13:22:55', '2025-06-01 13:22:55', 'Available', 'CAL002'),
(27, 'Shrimp Cocktail', 'Chilled shrimp served with tangy cocktail sauce and fresh lemon', 60000.00, 'uploads/683c54b6b9a8a_Shrimp Cocktail.jpg', 'Appetizer', '2025-06-01 13:25:10', '2025-06-01 13:25:10', 'Available', 'SHR003'),
(28, 'Miso Soup with Clams', 'Warm miso broth with fresh clams and scallions', 30000.00, 'uploads/683c5515d6d73_Miso Soup Recipe.jpg', 'Appetizer', '2025-06-01 13:26:45', '2025-06-01 13:26:45', 'Available', 'SOU006'),
(29, 'Garlic Butter Mussels', 'Steamed mussels in a rich garlic butter sauce', 75000.00, 'uploads/683c55a058722_Garlic Mussels in Sour Cream.jpg', 'Appetizer', '2025-06-01 13:29:04', '2025-06-01 13:29:04', 'Available', 'MUS00'),
(30, 'Mini Tuna Tartare', 'Fresh diced tuna mixed with avocado and sesame soy dressing', 55000.00, 'uploads/683c5635b1ceb_Spicy Tuna Tartare.jpg', 'Appetizer', '2025-06-01 13:31:33', '2025-06-01 13:31:33', 'Available', 'TAR015'),
(31, 'Seafood Spring Rolls', 'Golden spring rolls filled with crab, shrimp, and vegetables', 40000.00, 'uploads/683c569cd40fa_Spring Rolls with Shrimp.jpg', 'Appetizer', '2025-06-01 13:33:16', '2025-06-01 13:33:16', 'Available', 'SPR016'),
(32, 'Scallop Skewers', 'Grilled scallops on skewers with a drizzle of garlic lime glaze', 65000.00, 'uploads/683c581511c3d_Grilled Shrimp and Scallop Skewers Recipe.jpg', 'Appetizer', '2025-06-01 13:39:33', '2025-06-01 13:39:33', 'Available', 'SCL017'),
(33, 'Crab Stuffed Mushrooms\"', 'Juicy mushrooms stuffed with creamy crab filling and herbs', 48000.00, 'uploads/683c588dc45e5_Crab Stuffed Mushrooms.jpg', 'Appetizer', '2025-06-01 13:41:33', '2025-06-01 13:41:33', 'Available', 'CRM018'),
(34, 'Coconut Panna Cotta', 'Smooth panna cotta infused with coconut cream and topped with tropical fruit', 40000.00, 'uploads/683c5c6d90e34_Creamy, dreamy, and effortlessly elegan Coconut Panna Cotta.jpg', 'Dessert', '2025-06-01 13:58:05', '2025-06-01 13:58:05', 'Available', 'DES007'),
(35, 'Key Lime Pie', 'Tangy key lime filling on a buttery crust, served chilled', 45000.00, 'uploads/683c5cbc9aa9d_Easy Homemade Key Lime Pie.jpg', 'Dessert', '2025-06-01 13:59:24', '2025-06-01 13:59:24', 'Available', 'DES019'),
(36, 'Mango Sticky Rice', 'Sweet sticky rice served with fresh mango slices and coconut milk', 38000.00, 'uploads/683c5d2553a1a_Mango Sticky Rice.jpg', 'Dessert', '2025-06-01 14:01:09', '2025-06-01 14:01:09', 'Available', 'DES020'),
(37, 'Lemon Sorbet', 'Refreshing lemon sorbet, perfect to cleanse the palate after seafood', 35000.00, 'uploads/683c5d7d1a5a5_Refreshing Lemon Sorbet Recipe.jpg', 'Dessert', '2025-06-01 14:02:37', '2025-06-01 14:02:37', 'Available', 'DES021'),
(38, 'Pineapple Upside Down Cake', 'Moist cake topped with caramelized pineapple rings', 42000.00, 'uploads/683c5dde40368_Flip the script with this classic Pineapple.jpg', 'Dessert', '2025-06-01 14:04:14', '2025-06-01 14:04:14', 'Available', 'DES022'),
(39, 'Sea Salt Caramel Brownie', 'Rich chocolate brownie with swirls of sea salt caramel', 40000.00, 'uploads/683c5e1ad4e52_Salted Caramel Brownies.jpg', 'Dessert', '2025-06-01 14:05:14', '2025-06-01 14:05:14', 'Available', 'DES023'),
(40, 'Banana Fritters', 'Crispy fried banana fritters drizzled with honey', 37000.00, 'uploads/683c5e5559ac9_Banana Fritters.jpg', 'Dessert', '2025-06-01 14:06:13', '2025-06-01 14:06:13', 'Available', 'DES024'),
(41, 'Coconut Lime Cheesecake', 'Creamy cheesecake infused with coconut and a hint of lime', 48000.00, 'uploads/683c5ec97e0de_Mango coconut lime cheesecake bars.jpg', 'Dessert', '2025-06-01 14:08:09', '2025-06-01 14:08:09', 'Available', 'DES025'),
(43, 'Cucumber Mint Cooler', 'Cool cucumber juice blended with mint and a splash of lime', 25000.00, 'uploads/683c5fc63f7bf_Cucumber Mint Cooler_ Refreshing Summer Beverage - Tastylicious.jpg', 'Beverage', '2025-06-01 14:12:22', '2025-06-01 14:12:22', 'Available', 'BEV026'),
(44, 'Coconut Water', 'Fresh young coconut water served chilled', 22000.00, 'uploads/683c605bb3b36_Coconut Water.jpg', 'Beverage', '2025-06-01 14:14:51', '2025-06-01 14:14:51', 'Available', 'BEV027'),
(45, 'Tropical Fruit Punch', 'Blend of tropical fruits like pineapple, orange, and passionfruit', 28000.00, 'uploads/683c609d95f4d_Island Vibes_ Tropical Recipes to Try.jpg', 'Beverage', '2025-06-01 14:15:57', '2025-06-01 14:15:57', 'Available', 'BEV028'),
(46, 'Iced Lychee Tea', 'Black tea with lychee syrup and lychee fruit', 23000.00, 'uploads/683c60e11de58_Lychee Tea.jpg', 'Beverage', '2025-06-01 14:17:05', '2025-06-01 14:17:05', 'Available', 'BEV029'),
(47, 'Sparkling Lemonade', 'Lemonade with a fizzy twist, garnished with mint', 26000.00, 'uploads/683c614cd2ea2_Sparkling Mint-Lime Iced Tea.jpg', 'Beverage', '2025-06-01 14:18:52', '2025-06-01 14:18:52', 'Available', 'BEV030'),
(48, 'Lemon Iced Tea', 'Refreshing iced tea with a hint of lemon', 20000.00, 'uploads/683c625e794f9_Lemon Tea.jpg', 'Beverage', '2025-06-01 14:23:26', '2025-06-01 14:23:26', 'Available', 'BEV008'),
(49, 'Ginger Lime Fiz', 'Spicy ginger ale mixed with fresh lime juice', 27000.00, 'uploads/683c62a47436f_Ginger Lime Fizz Mocktail Recipe_ Refreshing Drink for Any Occasion.jpg', 'Beverage', '2025-06-01 14:24:36', '2025-06-01 14:24:36', 'Available', 'BEV031'),
(50, 'Mango Smoothie', 'Creamy mango smoothie made with fresh mangoes and yogurt', 30000.00, 'uploads/683c630f46d09_Mango Tango Smoothie.jpg', 'Beverage', '2025-06-01 14:26:23', '2025-06-01 14:26:23', 'Available', 'BEV032');

-- --------------------------------------------------------

--
-- Struktur dari tabel `menu_ingredients`
--

CREATE TABLE `menu_ingredients` (
  `id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  `stock_id` int(11) NOT NULL,
  `quantity_used` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `menu_ingredients`
--

INSERT INTO `menu_ingredients` (`id`, `menu_id`, `stock_id`, `quantity_used`) VALUES
(73, 18, 4, 1),
(74, 19, 14, 0.2),
(76, 21, 16, 1),
(77, 20, 7, 0.3),
(78, 22, 4, 0.5),
(79, 23, 14, 0.3),
(80, 24, 7, 0.4),
(81, 25, 4, 1),
(82, 26, 7, 0.2),
(83, 27, 5, 1),
(84, 28, 7, 0.2),
(85, 29, 23, 0.2),
(86, 30, 4, 1),
(87, 31, 7, 0.5),
(88, 32, 4, 1),
(89, 33, 12, 0.1),
(90, 34, 27, 0.1),
(91, 35, 28, 2),
(92, 36, 29, 0.5),
(93, 37, 30, 0.1),
(94, 38, 31, 0.3),
(95, 39, 32, 0.2),
(96, 40, 33, 0.2),
(97, 41, 28, 1),
(98, 41, 14, 0.4),
(100, 43, 34, 0.3),
(101, 43, 28, 2),
(102, 44, 27, 0.1),
(103, 45, 36, 0.3),
(104, 46, 35, 0.4),
(105, 47, 30, 0.2),
(107, 48, 30, 0.1),
(108, 49, 28, 2),
(109, 50, 29, 1);

-- --------------------------------------------------------

--
-- Struktur dari tabel `orders`
--

CREATE TABLE `orders` (
  `id_order` int(11) NOT NULL,
  `id_pelanggan` int(16) NOT NULL,
  `total_price` decimal(10,2) NOT NULL,
  `created_at` datetime NOT NULL,
  `midtrans_order_id` varchar(50) DEFAULT NULL,
  `order_type` enum('dine-in','delivery') NOT NULL DEFAULT 'dine-in'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `orders`
--

INSERT INTO `orders` (`id_order`, `id_pelanggan`, `total_price`, `created_at`, `midtrans_order_id`, `order_type`) VALUES
(6, 1, 330000.00, '2025-06-07 06:24:40', NULL, 'dine-in'),
(7, 1, 120000.00, '2025-06-07 06:29:34', NULL, 'dine-in'),
(8, 1, 195000.00, '2025-06-07 06:32:32', NULL, 'dine-in'),
(9, 1, 70000.00, '2025-06-07 06:33:04', NULL, 'dine-in'),
(10, 1, 335000.00, '2025-06-07 06:33:24', NULL, 'dine-in'),
(11, 1, 240000.00, '2025-06-07 06:35:48', NULL, 'dine-in'),
(12, 1, 190000.00, '2025-06-07 06:39:47', NULL, 'dine-in'),
(13, 1, 120000.00, '2025-06-07 06:40:10', NULL, 'dine-in'),
(14, 1, 70000.00, '2025-06-07 06:42:32', NULL, 'dine-in'),
(15, 1, 120000.00, '2025-06-07 06:47:09', NULL, 'dine-in'),
(16, 1, 70000.00, '2025-06-07 19:37:37', NULL, 'dine-in'),
(17, 1, 170000.00, '2025-06-07 19:46:20', NULL, 'dine-in'),
(18, 1, 120000.00, '2025-06-07 19:51:53', NULL, 'dine-in'),
(19, 1, 140000.00, '2025-06-07 21:12:54', NULL, 'dine-in'),
(20, 1, 195000.00, '2025-06-08 21:05:43', NULL, 'dine-in'),
(21, 1, 195000.00, '2025-06-08 21:10:48', 'ORDER-1749391848-4444', 'dine-in'),
(22, 1, 243000.00, '2025-06-08 21:49:42', 'ORDER-1749394182-9327', 'dine-in'),
(23, 1, 243000.00, '2025-06-08 22:03:00', 'ORDER-1749394980-2200', 'dine-in'),
(24, 1, 360000.00, '2025-06-08 22:06:11', 'ORDER-1749395171-3353', 'dine-in'),
(25, 1, 430000.00, '2025-06-08 22:45:24', 'ORDER-1749397524-7067', 'dine-in'),
(26, 1, 430000.00, '2025-06-08 22:51:42', 'ORDER-1749397902-3325', 'dine-in'),
(27, 1, 430000.00, '2025-06-08 23:05:04', 'ORDER-1749398704-8164', 'dine-in'),
(28, 1, 430000.00, '2025-06-08 23:07:09', 'ORDER-1749398829-5890', 'dine-in'),
(29, 1, 770000.00, '2025-06-08 23:08:29', 'ORDER-1749398909-4121', 'dine-in'),
(30, 1, 770000.00, '2025-06-08 23:12:02', 'ORDER-1749399122-6378', 'dine-in'),
(31, 1, 1440000.00, '2025-06-08 23:18:43', 'ORDER-1749399523-6260', 'dine-in'),
(32, 1, 1560000.00, '2025-06-08 23:22:06', 'ORDER-1749399726-1617', 'dine-in'),
(33, 1, 1560000.00, '2025-06-08 23:22:25', 'ORDER-1749399745-3938', 'dine-in'),
(34, 1, 1588000.00, '2025-06-08 23:26:01', 'ORDER-1749399961-1880', 'dine-in'),
(35, 1, 1708000.00, '2025-06-08 23:29:54', 'ORDER-1749400194-2857', 'dine-in'),
(36, 1, 1828000.00, '2025-06-08 23:30:12', 'ORDER-1749400212-3001', 'dine-in'),
(37, 1, 1828000.00, '2025-06-08 23:33:06', 'ORDER-1749400386-8601', 'dine-in'),
(38, 1, 1828000.00, '2025-06-08 23:33:09', 'ORDER-1749400389-6349', 'dine-in'),
(39, 1, 1828000.00, '2025-06-08 23:33:10', 'ORDER-1749400390-9913', 'dine-in'),
(40, 1, 1828000.00, '2025-06-08 23:35:19', 'ORDER-1749400519-9872', 'dine-in'),
(41, 1, 1008000.00, '2025-06-08 23:38:39', 'ORDER-1749400719-4950', 'dine-in'),
(42, 1, 1128000.00, '2025-06-08 23:39:56', 'ORDER-1749400796-8256', 'dine-in'),
(43, 1, 140000.00, '2025-06-08 23:42:36', 'ORDER-1749400956-5206', 'dine-in'),
(44, 1, 140000.00, '2025-06-08 23:44:24', 'ORDER-1749401064-7273', 'dine-in'),
(45, 1, 70000.00, '2025-06-08 23:50:30', 'ORDER-1749401430-6238', 'dine-in'),
(46, 1, 305000.00, '2025-06-08 23:55:53', 'ORDER-1749401753-5463', 'dine-in'),
(47, 1, 305000.00, '2025-06-08 23:57:32', 'ORDER-1749401852-4405', 'dine-in'),
(48, 1, 85000.00, '2025-06-09 00:00:15', 'ORDER-1749402015-6056', 'dine-in'),
(49, 1, 70000.00, '2025-06-09 00:00:57', 'ORDER-1749402057-9846', 'dine-in'),
(50, 1, 28000.00, '2025-06-09 00:02:02', 'ORDER-1749402122-7745', 'dine-in'),
(51, 1, 27000.00, '2025-06-09 00:07:02', 'ORDER-1749402422-3853', 'dine-in'),
(52, 1, 310000.00, '2025-06-09 00:07:37', 'ORDER-1749402457-4092', 'dine-in'),
(53, 1, 120000.00, '2025-06-09 00:11:13', 'ORDER-1749402673-3721', 'dine-in'),
(54, 1, 310000.00, '2025-06-09 00:12:00', 'ORDER-1749402720-7208', 'dine-in'),
(55, 1, 380000.00, '2025-06-09 00:13:19', 'ORDER-1749402799-6742', 'dine-in'),
(56, 1, 380000.00, '2025-06-09 00:13:21', 'ORDER-1749402801-9688', 'dine-in'),
(57, 1, 120000.00, '2025-06-09 00:38:24', 'ORDER-1749404304-3723', 'dine-in'),
(58, 1, 30000.00, '2025-06-09 00:40:20', 'ORDER-1749404420-5441', 'dine-in'),
(59, 1, 120000.00, '2025-06-10 22:51:37', 'ORDER-1749570697-1781', 'dine-in'),
(60, 1, 28000.00, '2025-06-10 22:56:01', 'ORDER-1749570961-6419', 'dine-in'),
(61, 1, 432000.00, '2025-06-10 22:58:37', 'ORDER-1749571117-2324', 'dine-in'),
(62, 1, 552000.00, '2025-06-10 23:04:29', 'ORDER-1749571469-6859', 'dine-in'),
(63, 1, 38000.00, '2025-06-10 23:13:16', 'ORDER-1749571996-8220', 'dine-in'),
(64, 1, 370000.00, '2025-06-10 23:24:31', 'ORDER-1749572671-1076', 'dine-in'),
(65, 1, 385000.00, '2025-06-10 23:25:31', 'ORDER-1749572731-8663', 'dine-in'),
(66, 1, 2220000.00, '2025-06-10 23:26:25', 'ORDER-1749572785-1649', 'dine-in'),
(67, 1, 250000.00, '2025-06-10 23:26:59', 'ORDER-1749572819-7255', 'dine-in'),
(68, 1, 120000.00, '2025-06-10 23:30:48', 'ORDER-1749573048-7950', 'dine-in'),
(69, 1, 455000.00, '2025-06-10 23:31:15', 'ORDER-1749573075-1465', 'dine-in'),
(70, 1, 120000.00, '2025-06-10 23:39:26', 'ORDER-1749573566-3478', 'dine-in'),
(71, 1, 190000.00, '2025-06-10 23:40:05', 'ORDER-1749573605-9182', 'dine-in'),
(72, 1, 250000.00, '2025-06-10 23:40:39', 'ORDER-1749573639-9813', 'dine-in'),
(73, 1, 70000.00, '2025-06-10 23:48:10', 'ORDER-1749574090-4677', 'dine-in'),
(74, 1, 190000.00, '2025-06-10 23:48:33', 'ORDER-1749574113-8713', 'dine-in'),
(75, 1, 70000.00, '2025-06-11 15:26:34', 'ORDER-1749630394-1100', 'dine-in'),
(76, 1, 190000.00, '2025-06-11 15:27:34', 'ORDER-1749630454-7314', 'dine-in'),
(77, 1, 50000.00, '2025-06-12 01:04:25', 'ORDER-1749665065-5342', 'dine-in'),
(78, 1, 120000.00, '2025-06-12 01:13:19', 'ORDER-1749665599-5166', 'dine-in'),
(79, 1, 250000.00, '2025-06-12 01:13:53', 'ORDER-1749665633-2428', 'dine-in'),
(80, 1, 250000.00, '2025-06-12 01:13:55', 'ORDER-1749665635-2951', 'dine-in'),
(81, 1, 190000.00, '2025-06-12 01:14:18', 'ORDER-1749665658-9661', 'dine-in'),
(82, 2, 250000.00, '2025-06-12 18:58:08', 'ORDER-1749729488-4497', 'dine-in'),
(83, 2, 190000.00, '2025-06-12 18:58:44', 'ORDER-1749729524-3876', 'dine-in'),
(84, 2, 250000.00, '2025-06-12 19:04:11', 'ORDER-1749729851-8788', 'dine-in'),
(85, 2, 525000.00, '2025-06-12 19:04:34', 'ORDER-1749729874-8517', 'dine-in'),
(86, 1, 250000.00, '2025-06-12 19:19:40', 'ORDER-1749730780-9846', 'dine-in'),
(87, 1, 250000.00, '2025-06-12 19:19:42', 'ORDER-1749730782-4752', 'dine-in'),
(88, 1, 3464000.00, '2025-06-12 19:20:38', 'ORDER-1749730838-8722', 'dine-in'),
(89, 1, 70000.00, '2025-06-20 17:37:35', 'ORDER-1750415855-1902', 'dine-in'),
(90, 1, 85000.00, '2025-06-21 05:58:28', 'ORDER-1750460308-1004', 'dine-in'),
(91, 1, 250000.00, '2025-06-21 06:23:00', 'ORDER-1750461780-1474', 'dine-in'),
(92, 1, 120000.00, '2025-06-21 06:45:16', 'ORDER-1750463116-4924', 'dine-in'),
(93, 1, 120000.00, '2025-06-21 07:11:03', 'ORDER-1750464663-6283', 'dine-in'),
(94, 1, 320000.00, '2025-06-21 07:11:52', 'ORDER-1750464712-1742', 'dine-in'),
(95, 1, 27000.00, '2025-06-21 11:17:02', 'ORDER-1750479422-4513', 'dine-in'),
(96, 1, 45000.00, '2025-06-21 11:24:48', 'ORDER-1750479888-3636', 'dine-in'),
(97, 1, 28000.00, '2025-06-21 23:15:25', 'ORDER-1750522525-6765', 'dine-in'),
(98, 1, 70000.00, '2025-06-22 21:43:00', 'ORDER-1750603380-9434', 'dine-in'),
(99, 5, 190000.00, '2025-06-22 22:23:22', 'ORDER-1750605802-9159', 'dine-in'),
(100, 7, 190000.00, '2025-06-22 22:32:04', 'ORDER-1750606324-6242', 'dine-in');

-- --------------------------------------------------------

--
-- Struktur dari tabel `order_items`
--

CREATE TABLE `order_items` (
  `id_order_item` int(11) NOT NULL,
  `id_order` int(11) NOT NULL,
  `id_menu` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `order_items`
--

INSERT INTO `order_items` (`id_order_item`, `id_order`, `id_menu`, `quantity`, `price`) VALUES
(1, 6, 21, 3, 70000.00),
(2, 6, 20, 1, 120000.00),
(3, 7, 20, 1, 120000.00),
(4, 8, 25, 1, 110000.00),
(5, 8, 24, 1, 85000.00),
(6, 9, 21, 1, 70000.00),
(7, 10, 19, 1, 250000.00),
(8, 10, 18, 1, 85000.00),
(9, 11, 20, 2, 120000.00),
(10, 12, 20, 1, 120000.00),
(11, 12, 21, 1, 70000.00),
(12, 13, 20, 1, 120000.00),
(13, 14, 21, 1, 70000.00),
(14, 15, 20, 1, 120000.00),
(15, 16, 21, 1, 70000.00),
(16, 17, 24, 2, 85000.00),
(17, 18, 20, 1, 120000.00),
(18, 19, 21, 2, 70000.00),
(19, 20, 24, 1, 85000.00),
(20, 20, 25, 1, 110000.00),
(21, 21, 24, 1, 85000.00),
(22, 21, 25, 1, 110000.00),
(23, 22, 20, 1, 120000.00),
(24, 22, 27, 1, 60000.00),
(25, 22, 36, 1, 38000.00),
(26, 22, 43, 1, 25000.00),
(27, 23, 20, 1, 120000.00),
(28, 23, 27, 1, 60000.00),
(29, 23, 36, 1, 38000.00),
(30, 23, 43, 1, 25000.00),
(31, 24, 20, 1, 120000.00),
(32, 24, 21, 1, 70000.00),
(33, 24, 24, 2, 85000.00),
(34, 25, 20, 1, 120000.00),
(35, 25, 21, 2, 70000.00),
(36, 25, 24, 2, 85000.00),
(37, 26, 20, 1, 120000.00),
(38, 26, 21, 2, 70000.00),
(39, 26, 24, 2, 85000.00),
(40, 27, 20, 1, 120000.00),
(41, 27, 21, 2, 70000.00),
(42, 27, 24, 2, 85000.00),
(43, 28, 20, 1, 120000.00),
(44, 28, 21, 2, 70000.00),
(45, 28, 24, 2, 85000.00),
(46, 29, 20, 2, 120000.00),
(47, 29, 21, 2, 70000.00),
(48, 29, 24, 2, 85000.00),
(49, 29, 25, 2, 110000.00),
(50, 30, 20, 2, 120000.00),
(51, 30, 21, 2, 70000.00),
(52, 30, 24, 2, 85000.00),
(53, 30, 25, 2, 110000.00),
(54, 31, 20, 4, 120000.00),
(55, 31, 21, 2, 70000.00),
(56, 31, 24, 2, 85000.00),
(57, 31, 25, 2, 110000.00),
(58, 31, 23, 2, 90000.00),
(59, 31, 19, 1, 250000.00),
(60, 32, 20, 5, 120000.00),
(61, 32, 21, 2, 70000.00),
(62, 32, 24, 2, 85000.00),
(63, 32, 25, 2, 110000.00),
(64, 32, 23, 2, 90000.00),
(65, 32, 19, 1, 250000.00),
(66, 33, 20, 5, 120000.00),
(67, 33, 21, 2, 70000.00),
(68, 33, 24, 2, 85000.00),
(69, 33, 25, 2, 110000.00),
(70, 33, 23, 2, 90000.00),
(71, 33, 19, 1, 250000.00),
(72, 34, 20, 5, 120000.00),
(73, 34, 21, 2, 70000.00),
(74, 34, 24, 2, 85000.00),
(75, 34, 25, 2, 110000.00),
(76, 34, 23, 2, 90000.00),
(77, 34, 19, 1, 250000.00),
(78, 34, 45, 1, 28000.00),
(79, 35, 20, 6, 120000.00),
(80, 35, 21, 2, 70000.00),
(81, 35, 24, 2, 85000.00),
(82, 35, 25, 2, 110000.00),
(83, 35, 23, 2, 90000.00),
(84, 35, 19, 1, 250000.00),
(85, 35, 45, 1, 28000.00),
(86, 36, 20, 7, 120000.00),
(87, 36, 21, 2, 70000.00),
(88, 36, 24, 2, 85000.00),
(89, 36, 25, 2, 110000.00),
(90, 36, 23, 2, 90000.00),
(91, 36, 19, 1, 250000.00),
(92, 36, 45, 1, 28000.00),
(93, 37, 20, 7, 120000.00),
(94, 37, 21, 2, 70000.00),
(95, 37, 24, 2, 85000.00),
(96, 37, 25, 2, 110000.00),
(97, 37, 23, 2, 90000.00),
(98, 37, 19, 1, 250000.00),
(99, 37, 45, 1, 28000.00),
(100, 38, 20, 7, 120000.00),
(101, 38, 21, 2, 70000.00),
(102, 38, 24, 2, 85000.00),
(103, 38, 25, 2, 110000.00),
(104, 38, 23, 2, 90000.00),
(105, 38, 19, 1, 250000.00),
(106, 38, 45, 1, 28000.00),
(107, 39, 20, 7, 120000.00),
(108, 39, 21, 2, 70000.00),
(109, 39, 24, 2, 85000.00),
(110, 39, 25, 2, 110000.00),
(111, 39, 23, 2, 90000.00),
(112, 39, 19, 1, 250000.00),
(113, 39, 45, 1, 28000.00),
(114, 40, 20, 7, 120000.00),
(115, 40, 21, 2, 70000.00),
(116, 40, 24, 2, 85000.00),
(117, 40, 25, 2, 110000.00),
(118, 40, 23, 2, 90000.00),
(119, 40, 19, 1, 250000.00),
(120, 40, 45, 1, 28000.00),
(121, 41, 20, 7, 120000.00),
(122, 41, 21, 2, 70000.00),
(123, 41, 45, 1, 28000.00),
(124, 42, 20, 8, 120000.00),
(125, 42, 21, 2, 70000.00),
(126, 42, 45, 1, 28000.00),
(127, 43, 21, 2, 70000.00),
(128, 44, 21, 2, 70000.00),
(129, 45, 21, 1, 70000.00),
(130, 46, 21, 1, 70000.00),
(131, 46, 20, 1, 120000.00),
(132, 46, 36, 1, 38000.00),
(133, 46, 39, 1, 40000.00),
(134, 46, 40, 1, 37000.00),
(135, 47, 21, 1, 70000.00),
(136, 47, 20, 1, 120000.00),
(137, 47, 36, 1, 38000.00),
(138, 47, 39, 1, 40000.00),
(139, 47, 40, 1, 37000.00),
(140, 48, 24, 1, 85000.00),
(141, 49, 21, 1, 70000.00),
(142, 50, 45, 1, 28000.00),
(143, 51, 49, 1, 27000.00),
(144, 52, 20, 2, 120000.00),
(145, 52, 21, 1, 70000.00),
(146, 53, 20, 1, 120000.00),
(147, 54, 20, 2, 120000.00),
(148, 54, 21, 1, 70000.00),
(149, 55, 20, 2, 120000.00),
(150, 55, 21, 2, 70000.00),
(151, 56, 20, 2, 120000.00),
(152, 56, 21, 2, 70000.00),
(153, 57, 20, 1, 120000.00),
(154, 58, 50, 1, 30000.00),
(155, 59, 20, 1, 120000.00),
(156, 60, 45, 1, 28000.00),
(157, 61, 20, 1, 120000.00),
(158, 61, 21, 1, 70000.00),
(159, 61, 27, 1, 60000.00),
(160, 61, 28, 1, 30000.00),
(161, 61, 34, 1, 40000.00),
(162, 61, 35, 1, 45000.00),
(163, 61, 39, 1, 40000.00),
(164, 61, 49, 1, 27000.00),
(165, 62, 20, 2, 120000.00),
(166, 62, 21, 1, 70000.00),
(167, 62, 27, 1, 60000.00),
(168, 62, 28, 1, 30000.00),
(169, 62, 34, 1, 40000.00),
(170, 62, 35, 1, 45000.00),
(171, 62, 39, 1, 40000.00),
(172, 62, 49, 1, 27000.00),
(173, 63, 36, 1, 38000.00),
(174, 64, 35, 2, 45000.00),
(175, 64, 21, 4, 70000.00),
(176, 65, 20, 1, 120000.00),
(177, 65, 21, 1, 70000.00),
(178, 65, 24, 1, 85000.00),
(179, 65, 25, 1, 110000.00),
(180, 66, 20, 1, 120000.00),
(181, 66, 21, 30, 70000.00),
(182, 67, 19, 1, 250000.00),
(183, 68, 20, 1, 120000.00),
(184, 69, 24, 1, 85000.00),
(185, 69, 25, 1, 110000.00),
(186, 69, 20, 1, 120000.00),
(187, 69, 21, 2, 70000.00),
(188, 70, 20, 1, 120000.00),
(189, 71, 20, 1, 120000.00),
(190, 71, 21, 1, 70000.00),
(191, 72, 19, 1, 250000.00),
(192, 73, 21, 1, 70000.00),
(193, 74, 21, 1, 70000.00),
(194, 74, 20, 1, 120000.00),
(195, 75, 21, 1, 70000.00),
(196, 76, 20, 1, 120000.00),
(197, 76, 21, 1, 70000.00),
(198, 17, 21, 1, 70000.00),
(199, 17, 28, 1, 30000.00),
(200, 17, 35, 1, 45000.00),
(201, 17, 43, 1, 25000.00),
(202, 18, 24, 1, 85000.00),
(203, 18, 25, 1, 110000.00),
(204, 77, 45, 1, 28000.00),
(205, 77, 44, 1, 22000.00),
(206, 19, 45, 1, 28000.00),
(207, 19, 44, 1, 22000.00),
(208, 20, 20, 1, 120000.00),
(209, 20, 19, 1, 250000.00),
(210, 21, 21, 1, 70000.00),
(211, 21, 20, 1, 120000.00),
(212, 22, 21, 1, 70000.00),
(213, 78, 20, 1, 120000.00),
(214, 79, 19, 1, 250000.00),
(215, 80, 19, 1, 250000.00),
(216, 81, 21, 1, 70000.00),
(217, 81, 20, 1, 120000.00),
(218, 23, 19, 1, 250000.00),
(219, 23, 18, 1, 85000.00),
(220, 23, 31, 1, 40000.00),
(221, 23, 32, 1, 65000.00),
(222, 23, 36, 1, 38000.00),
(223, 23, 37, 1, 35000.00),
(224, 23, 46, 1, 23000.00),
(225, 23, 44, 1, 22000.00),
(226, 24, 20, 1, 120000.00),
(227, 24, 21, 1, 70000.00),
(228, 24, 19, 1, 250000.00),
(229, 24, 18, 1, 85000.00),
(230, 25, 23, 1, 90000.00),
(231, 25, 22, 1, 95000.00),
(232, 25, 24, 1, 85000.00),
(233, 25, 25, 1, 110000.00),
(234, 82, 19, 1, 250000.00),
(235, 83, 20, 1, 120000.00),
(236, 83, 21, 1, 70000.00),
(237, 84, 19, 1, 250000.00),
(238, 85, 20, 1, 120000.00),
(239, 85, 21, 1, 70000.00),
(240, 85, 19, 1, 250000.00),
(241, 85, 18, 1, 85000.00),
(242, 86, 19, 1, 250000.00),
(243, 87, 19, 1, 250000.00),
(244, 88, 20, 20, 120000.00),
(245, 88, 21, 1, 70000.00),
(246, 88, 19, 1, 250000.00),
(247, 88, 18, 1, 85000.00),
(248, 88, 23, 1, 90000.00),
(249, 88, 22, 1, 95000.00),
(250, 88, 24, 1, 85000.00),
(251, 88, 25, 1, 110000.00),
(252, 88, 31, 1, 40000.00),
(253, 88, 32, 1, 65000.00),
(254, 88, 33, 1, 48000.00),
(255, 88, 36, 1, 38000.00),
(256, 88, 37, 1, 35000.00),
(257, 88, 46, 1, 23000.00),
(258, 88, 50, 1, 30000.00),
(259, 26, 20, 1, 120000.00),
(260, 26, 25, 2, 110000.00),
(261, 26, 24, 1, 85000.00),
(262, 27, 21, 1, 70000.00),
(263, 27, 19, 1, 250000.00),
(264, 89, 21, 1, 70000.00),
(265, 29, 20, 1, 120000.00),
(266, 29, 19, 1, 250000.00),
(267, 30, 23, 2, 90000.00),
(268, 30, 24, 1, 85000.00),
(269, 90, 24, 1, 85000.00),
(270, 91, 19, 1, 250000.00),
(271, 92, 20, 1, 120000.00),
(272, 93, 20, 1, 120000.00),
(273, 94, 19, 1, 250000.00),
(274, 94, 21, 1, 70000.00),
(275, 95, 49, 1, 27000.00),
(276, 96, 26, 1, 45000.00),
(277, 97, 45, 1, 28000.00),
(278, 98, 21, 1, 70000.00),
(279, 99, 20, 1, 120000.00),
(280, 99, 21, 1, 70000.00),
(281, 100, 20, 1, 120000.00),
(282, 100, 21, 1, 70000.00);

-- --------------------------------------------------------

--
-- Struktur dari tabel `pelanggan`
--

CREATE TABLE `pelanggan` (
  `id_pelanggan` int(16) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `no_hp` varchar(15) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `reset_token` varchar(255) NOT NULL,
  `token_expired` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `pelanggan`
--

INSERT INTO `pelanggan` (`id_pelanggan`, `firstname`, `lastname`, `email`, `no_hp`, `username`, `password`, `reset_token`, `token_expired`) VALUES
(1, 'Nivia', 'Nur Kharisma', 'nivianurkh04@gmail.com', '081223179627', 'nivia.nur', '$2y$10$FyD9Rm9cwtAnUK5MbMNSde2fLmkkV9dceiamz7V.lKxL0kDLy7MZ6', '286fa73439435e17753c7ae15ffe46d764178e9514c42a50aed28e6b9d6b72ce', '2025-06-22 23:31:39'),
(2, 'Mees', 'Hilgers', 'mees@gmail.com', '0812231796277', 'mees.h', '$2y$10$Krplfd/0DQhcq.kqG/qFmer0AfSqRQq2c/rYUi8ksWJK6yso2rJGK', '', '0000-00-00 00:00:00'),
(3, 'Rafael', 'Struick', 'rafael@gmail.com', '081234567890', 'rafael', '$2y$10$tUYnjjd18yV6w/q13sJfJODfa65u9KKyJ0NkpyhLLPU9ENd2GCuc2', '', '0000-00-00 00:00:00'),
(4, 'Anisa', 'Indriani', 'anisaindri@gmail.com', '0812345679023', 'anisaa.indri', '$2y$10$1pzmzebBret/wJldbjdZoeRYWs/Phtj.mwfI6wyn8UoBb2Gx7LKoy', '', '0000-00-00 00:00:00'),
(5, 'Pedri', 'Gonzales', 'niviankh@gmail.com', '081223179652', 'pedri.g', '$2y$10$KlGEWLy9uLbYiE.Asc05xul25LmFQOtcJBc4hbsuKhNIAOXQFevay', '', '0000-00-00 00:00:00'),
(6, 'Anisa', 'Indriani', 'anisa.indriani@gmail.com', '081234576890', 'anisa.indri', '$2y$10$IE2WD0Rz0jAfp/HAkhVHQ.mGosRcfZroW3ByePOo9G8nGaCRqyJGy', '', '0000-00-00 00:00:00'),
(7, 'Pablo', 'Gavi', 'pablogavi@gmail.com', '081234658902', 'gavi.pablo', '$2y$10$m4.AeIV/z/vB.VsxVOcRDesn0dqD88FoxPHzxaSySSU8mLOQe/V4K', '', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Struktur dari tabel `stock`
--

CREATE TABLE `stock` (
  `id` int(11) NOT NULL,
  `ingredient_name` varchar(255) NOT NULL,
  `ingredient_code` varchar(100) NOT NULL,
  `quantity` float NOT NULL,
  `expired_date` date DEFAULT NULL,
  `unit` enum('Gram (g)','Kilogram (kg)','Piece (pcs)','Liter (L)','Milliliter (ml)','Pack','Bunch','Slice','Can','Bottle','Box','Dozen') NOT NULL,
  `minimum_stock` float NOT NULL,
  `status` enum('Out of Stock','Low Stock','In Stock') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `stock`
--

INSERT INTO `stock` (`id`, `ingredient_name`, `ingredient_code`, `quantity`, `expired_date`, `unit`, `minimum_stock`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Beef Patty', 'BP001', 50, '2025-06-01', 'Piece (pcs)', 10, 'Out of Stock', '2025-05-11 04:15:26', '2025-05-11 04:39:36'),
(2, 'Burger Bun', 'BB001', 100, '2025-06-05', 'Piece (pcs)', 20, 'In Stock', '2025-05-11 04:15:26', '2025-05-11 04:15:26'),
(4, 'Lettuce', 'LT001', 30, '2025-05-20', 'Bunch', 5, 'Low Stock', '2025-05-11 04:15:26', '2025-05-11 04:15:26'),
(5, 'Tomato', 'TM001', 40, '2025-05-18', 'Piece (pcs)', 10, 'In Stock', '2025-05-11 04:15:26', '2025-05-11 04:15:26'),
(6, 'Tomatoe', 'TM033', 40, '2025-05-18', 'Piece (pcs)', 10, 'In Stock', '2025-05-11 04:15:26', '2025-05-11 04:15:26'),
(7, 'Sayur', 'SA092', 2, '2025-05-22', 'Kilogram (kg)', 2, 'Out of Stock', '2025-05-11 08:02:06', '2025-05-11 08:02:06'),
(11, 'Daging', '897', 89, '2025-05-29', 'Piece (pcs)', 7, 'Out of Stock', '2025-05-11 08:21:08', '2025-05-11 08:21:08'),
(12, 'sayu', 'dsdjn', 89, '2025-05-23', 'Kilogram (kg)', 8, 'Low Stock', '2025-05-11 08:22:21', '2025-05-11 08:22:21'),
(14, 'Keju', '8929j', 2, '2025-05-22', 'Kilogram (kg)', 3, 'In Stock', '2025-05-11 08:24:29', '2025-05-11 08:24:29'),
(16, 'selada airr', 'qqwe', 0, '2025-05-07', 'Milliliter (ml)', 0, 'Low Stock', '2025-05-11 08:27:30', '2025-05-11 09:13:40'),
(17, 'yh', 'bh', -3, '2025-06-05', 'Kilogram (kg)', 8, 'Out of Stock', '2025-05-11 08:28:00', '2025-05-11 08:28:00'),
(18, 'ua', 'i', 8, '2025-05-23', 'Piece (pcs)', 8, 'In Stock', '2025-05-11 08:32:34', '2025-05-11 08:32:34'),
(19, 'fafa', 'h7e82', 0, '2025-05-21', 'Piece (pcs)', 0, 'Out of Stock', '2025-05-11 08:42:02', '2025-05-11 08:42:02'),
(20, 'ndj', 'dnjte', 2, '2025-05-29', 'Kilogram (kg)', 3, 'Out of Stock', '2025-05-11 08:42:19', '2025-05-11 08:42:19'),
(21, 'jn', 'e23', 0, '2025-05-23', 'Liter (L)', 0, 'Out of Stock', '2025-05-11 08:42:37', '2025-05-11 08:42:37'),
(22, 'Keju', 'K123', 7, '2025-05-31', 'Slice', 3, 'Low Stock', '2025-05-12 02:48:36', '2025-05-12 02:48:36'),
(23, 'Bawang daun', 'BW123', 4, '2025-05-31', 'Gram (g)', 2, 'In Stock', '2025-05-13 11:53:55', '2025-05-13 11:53:55'),
(24, 'Roti', 'A012356', 7, '2025-05-30', 'Slice', 2, 'In Stock', '2025-05-17 03:38:19', '2025-05-17 03:38:19'),
(25, 'Mushroom', 'M123', 30, '2026-03-12', 'Pack', 3, 'In Stock', '2025-06-01 13:43:05', '2025-06-01 13:43:05'),
(26, 'Butter', 'B123', 30, '2026-01-01', 'Pack', 2, 'In Stock', '2025-06-01 13:43:46', '2025-06-01 13:43:46'),
(27, 'Coconut', 'CO123', 30, '2025-06-26', 'Box', 1, 'In Stock', '2025-06-01 13:47:07', '2025-06-01 13:47:07'),
(28, 'Lime', 'LI123', 30, '2025-10-31', 'Piece (pcs)', 2, 'In Stock', '2025-06-01 13:47:58', '2025-06-01 13:47:58'),
(29, 'Mango', 'MA123', 30, '2025-08-28', 'Piece (pcs)', 4, 'In Stock', '2025-06-01 13:49:10', '2025-06-01 13:49:10'),
(30, 'Lemon', 'LE123', 30, '2025-08-31', 'Kilogram (kg)', 2, 'In Stock', '2025-06-01 13:51:06', '2025-06-01 13:51:06'),
(31, 'Pienapple', 'PI123', 30, '2025-09-30', 'Piece (pcs)', 1, 'In Stock', '2025-06-01 13:52:04', '2025-06-01 13:52:04'),
(32, 'Sugar', 'SU123', 30, '2026-04-21', 'Kilogram (kg)', 1, 'In Stock', '2025-06-01 13:52:55', '2025-06-01 13:52:55'),
(33, 'Banana', 'BA123', 30, '2025-12-24', 'Pack', 2, 'In Stock', '2025-06-01 13:53:33', '2025-06-01 13:53:33'),
(34, 'Cucumber', 'CU123', 30, '2025-09-19', 'Pack', 1, 'In Stock', '2025-06-01 13:54:20', '2025-06-01 13:54:20'),
(35, 'Lychee', 'LY123', 30, '2025-08-28', 'Pack', 2, 'In Stock', '2025-06-01 13:55:19', '2025-06-01 13:55:19'),
(36, 'Fruit', 'FU123', 60, '2026-05-06', 'Bunch', 4, 'In Stock', '2025-06-01 13:56:20', '2025-06-01 13:56:20'),
(1, 'Beef Patty', 'BP001', 50, '2025-06-01', 'Piece (pcs)', 10, 'Out of Stock', '2025-05-11 04:15:26', '2025-05-11 04:39:36'),
(2, 'Burger Bun', 'BB001', 100, '2025-06-05', 'Piece (pcs)', 20, 'In Stock', '2025-05-11 04:15:26', '2025-05-11 04:15:26'),
(4, 'Lettuce', 'LT001', 30, '2025-05-20', 'Bunch', 5, 'Low Stock', '2025-05-11 04:15:26', '2025-05-11 04:15:26'),
(5, 'Tomato', 'TM001', 40, '2025-05-18', 'Piece (pcs)', 10, 'In Stock', '2025-05-11 04:15:26', '2025-05-11 04:15:26'),
(6, 'Tomatoe', 'TM033', 40, '2025-05-18', 'Piece (pcs)', 10, 'In Stock', '2025-05-11 04:15:26', '2025-05-11 04:15:26'),
(7, 'Sayur', 'SA092', 2, '2025-05-22', 'Kilogram (kg)', 2, 'Out of Stock', '2025-05-11 08:02:06', '2025-05-11 08:02:06'),
(11, 'Daging', '897', 89, '2025-05-29', 'Piece (pcs)', 7, 'Out of Stock', '2025-05-11 08:21:08', '2025-05-11 08:21:08'),
(12, 'sayu', 'dsdjn', 89, '2025-05-23', 'Kilogram (kg)', 8, 'Low Stock', '2025-05-11 08:22:21', '2025-05-11 08:22:21'),
(14, 'Keju', '8929j', 2, '2025-05-22', 'Kilogram (kg)', 3, 'In Stock', '2025-05-11 08:24:29', '2025-05-11 08:24:29'),
(16, 'selada airr', 'qqwe', 0, '2025-05-07', 'Milliliter (ml)', 0, 'Low Stock', '2025-05-11 08:27:30', '2025-05-11 09:13:40'),
(17, 'yh', 'bh', -3, '2025-06-05', 'Kilogram (kg)', 8, 'Out of Stock', '2025-05-11 08:28:00', '2025-05-11 08:28:00'),
(18, 'ua', 'i', 8, '2025-05-23', 'Piece (pcs)', 8, 'In Stock', '2025-05-11 08:32:34', '2025-05-11 08:32:34'),
(19, 'fafa', 'h7e82', 0, '2025-05-21', 'Piece (pcs)', 0, 'Out of Stock', '2025-05-11 08:42:02', '2025-05-11 08:42:02'),
(20, 'ndj', 'dnjte', 2, '2025-05-29', 'Kilogram (kg)', 3, 'Out of Stock', '2025-05-11 08:42:19', '2025-05-11 08:42:19'),
(21, 'jn', 'e23', 0, '2025-05-23', 'Liter (L)', 0, 'Out of Stock', '2025-05-11 08:42:37', '2025-05-11 08:42:37'),
(22, 'Keju', 'K123', 7, '2025-05-31', 'Slice', 3, 'Low Stock', '2025-05-12 02:48:36', '2025-05-12 02:48:36'),
(23, 'Bawang daun', 'BW123', 4, '2025-05-31', 'Gram (g)', 2, 'In Stock', '2025-05-13 11:53:55', '2025-05-13 11:53:55'),
(24, 'Roti', 'A012356', 7, '2025-05-30', 'Slice', 2, 'In Stock', '2025-05-17 03:38:19', '2025-05-17 03:38:19');

-- --------------------------------------------------------

--
-- Struktur dari tabel `table_reservations`
--

CREATE TABLE `table_reservations` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `reservation_datetime` datetime NOT NULL,
  `number_of_people` int(11) NOT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `special_request` text DEFAULT NULL,
  `status` enum('pending','approved','rejected','claimed') DEFAULT 'pending',
  `rejection_reason` text DEFAULT NULL,
  `payment_status` enum('Unpaid','Paid') DEFAULT 'Unpaid',
  `qr_code` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `transaction_id` varchar(50) DEFAULT NULL,
  `transaction_code` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `table_reservations`
--

INSERT INTO `table_reservations` (`id`, `name`, `email`, `phone`, `reservation_datetime`, `number_of_people`, `price`, `special_request`, `status`, `rejection_reason`, `payment_status`, `qr_code`, `created_at`, `transaction_id`, `transaction_code`) VALUES
(10, 'Anisa', 'anisa.indriani@widyatama.ac.id', '083923233232', '2025-06-21 17:46:00', 2, NULL, 'aaaa', 'rejected', 'meja ga ada yg kosong', 'Unpaid', NULL, '2025-05-12 10:46:13', NULL, NULL),
(29, 'Shelvia', 'shelvia@mailinator.com', '08793232323', '2025-05-18 10:42:00', 5, NULL, 'Ingin ada lilin', 'pending', NULL, 'Unpaid', NULL, '2025-05-17 03:43:15', NULL, NULL),
(30, 'Mei', 'mei@mailinator.com', '08927332323', '2025-05-12 21:35:00', 4, 80000.00, 'Test harga', 'pending', NULL, 'Unpaid', NULL, '2025-05-24 02:05:46', NULL, NULL),
(31, 'Juanita', 'juanita@mailinator.com', '08297332323', '2025-06-20 09:14:00', 3, 60000.00, 'Dekatt jendela', 'rejected', 'Yess', 'Unpaid', NULL, '2025-05-24 02:17:30', 'RESV-68312C3A338FB', NULL),
(32, 'Yumna', 'yumna@mailinator.com', '08972332323', '2025-05-24 09:17:00', 3, 60000.00, 'Oke', 'approved', NULL, 'Unpaid', NULL, '2025-05-24 02:17:57', 'RESV-68312C55795CD', NULL),
(33, 'Yudi', 'yudi@mailinator.com', '089732323224', '2025-05-12 21:35:00', 4, 80000.00, 'Test', 'approved', NULL, 'Unpaid', NULL, '2025-05-24 02:30:36', 'RESV-68312F4C2B9F6', NULL),
(34, 'Ananda', 'ananda@mailinator.com', '08763234343', '2025-05-12 17:38:00', 2, 40000.00, 'Test', 'approved', NULL, 'Unpaid', NULL, '2025-05-24 02:56:28', 'RESV-6831357B1D783', NULL),
(35, 'Nivia nur', 'nivianur@mailinator.com', '08973798322', '2025-05-12 21:35:00', 4, 80000.00, 'test', 'rejected', 'Table penuh', 'Unpaid', NULL, '2025-05-24 03:01:17', NULL, NULL),
(36, 'Kayla', 'kayla@mailinator.com', '08973243444', '2025-05-27 10:00:00', 3, 60000.00, 'Tempat duduk dekat jendela', 'approved', NULL, 'Unpaid', NULL, '2025-05-24 03:59:03', 'RESV-68314823A8D81', NULL),
(37, 'Ratih', 'ratih@mailinator.com', '087973245', '2025-05-12 21:35:00', 4, 80000.00, 'Test', 'approved', NULL, 'Unpaid', NULL, '2025-05-25 03:23:31', 'RESV-68328D95027E4', NULL),
(38, 'Nur', 'nur@mailinator.com', '08937678323', '2025-05-12 21:35:00', 3, 60000.00, 'Test', 'pending', NULL, 'Unpaid', NULL, '2025-05-25 03:31:10', NULL, NULL),
(39, 'Hani', 'hani@mailinator.com', '08973923323', '2025-05-12 21:35:00', 3, 60000.00, 'Test', 'approved', NULL, 'Unpaid', NULL, '2025-05-25 03:53:17', 'RESV-683294FF48B12', NULL),
(40, 'Nona', 'nona@mailinator.com', '0839434343434', '2025-05-12 17:38:00', 3, 60000.00, 'Test', 'approved', NULL, 'Unpaid', NULL, '2025-05-25 04:02:42', 'RESV-68329701DDB76', NULL),
(41, 'Mili', 'mili@mailinator.com', '083927243434', '2025-05-12 21:35:00', 3, 60000.00, 'Test', 'approved', NULL, 'Unpaid', NULL, '2025-05-25 04:06:43', 'RESV-6832975FD7638', NULL),
(42, 'Novi', 'novi@mailinator.com', '0839743434', '2025-05-12 21:35:00', 2, 40000.00, 'Test', 'approved', NULL, 'Unpaid', NULL, '2025-05-25 04:13:28', 'RESV-6832995AB7821', NULL),
(43, 'Yana', 'yana@mailinator.com', '07382932739', '2025-05-25 11:20:00', 3, 60000.00, 'Test', 'approved', NULL, 'Unpaid', NULL, '2025-05-25 04:20:57', 'RESV-68329AB4654DC', NULL),
(44, 'Yesa', 'yesa@mailinator.com', '033343434', '2025-05-12 21:35:00', 3, 60000.00, 'Tes', 'approved', NULL, 'Unpaid', NULL, '2025-05-25 04:23:26', 'RESV-68329B4C19D8D', NULL),
(45, 'Noe', 'noe@mailinator.com', '08392732897', '2025-05-12 17:38:00', 3, 60000.00, 'Tes', 'approved', NULL, 'Unpaid', NULL, '2025-05-25 04:59:30', NULL, NULL),
(46, 'taka', 'taka@mailinator.com', '0398473489', '2025-05-12 21:35:00', 3, 60000.00, 'Tes', 'approved', NULL, 'Unpaid', NULL, '2025-05-25 05:00:50', 'RESV-6832A4157CA20', NULL),
(47, 'coki', 'coki@mailinator.com', '083972323', '2025-05-12 17:38:00', 3, 60000.00, 'tes', 'approved', NULL, 'Unpaid', NULL, '2025-05-25 05:02:55', 'RESV-6832A49003987', NULL),
(48, 'Dika', 'dika@mailinator.com', '0872934343', '2025-05-12 17:38:00', 3, 60000.00, 'Tes', 'approved', NULL, 'Unpaid', NULL, '2025-05-25 05:06:27', NULL, 'RESV-6832A56B164BB'),
(49, 'Test Meja', 'meja@mailinator.com', '0837982733', '2025-05-12 21:35:00', 2, 40000.00, 'Test', 'approved', NULL, 'Unpaid', NULL, '2025-05-31 02:43:17', NULL, 'RESV-683A6D2492901'),
(50, 'Cahya', 'cahya@mailinator.com', '087934344', '2025-06-21 10:53:00', 2, 40000.00, 'Ada lilin', 'approved', NULL, 'Paid', 'https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=RESV-6855F8DC66AD5', '2025-06-20 23:53:25', NULL, 'RESV-6855F8DC66AD5'),
(51, 'Anisa', 'anisa.indriani@widyatama.ac.id', '0789233232', '2025-06-21 07:33:00', 2, 40000.00, 'Pengen dekat jendela', 'claimed', NULL, 'Paid', 'https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=RESV-6855FDFAD3383', '2025-06-21 00:33:28', NULL, 'RESV-6855FDFAD3383'),
(52, 'nivianurkh', 'nivianurkh04@gmail.com', '081223179627', '2025-06-24 10:57:00', 3, 60000.00, 'aaaaa', 'pending', NULL, 'Unpaid', NULL, '2025-06-21 04:01:02', NULL, NULL),
(53, 'nivianurkh', 'nivianurkh04@gmail.com', '081223179627', '2025-06-24 10:57:00', 8, 160000.00, 'bismillah', 'pending', NULL, 'Unpaid', NULL, '2025-06-21 04:01:35', NULL, NULL),
(54, 'nivianurkh', 'nivianurkh04@gmail.com', '081223179627', '2025-06-24 10:57:00', 8, 160000.00, 'bismillah', 'approved', NULL, 'Unpaid', 'https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=RESV-68562EE7AFC61', '2025-06-21 04:01:42', NULL, 'RESV-68562EE7AFC61'),
(55, 'Anisa', 'nivianurkh04@gmail.com', '081223179627', '2025-03-22 08:14:00', 4, 80000.00, 'Pengen deket jendela', 'approved', NULL, 'Unpaid', 'https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=RESV-68563589321D5', '2025-06-21 04:28:02', NULL, 'RESV-68563589321D5'),
(56, 'Nivia Nur Kharisma', 'nivianurkh04@gmail.com', '081223179627', '2025-07-03 23:45:00', 8, 160000.00, 'ada timnas', 'approved', NULL, 'Paid', 'https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=RESV-6856E21B1F014', '2025-06-21 16:45:46', NULL, 'RESV-6856E21B1F014'),
(57, 'nivianurkh', 'nivianurkh04@gmail.com', '081223179627', '2025-07-12 22:46:00', 4, 80000.00, 'Barca Treble', 'pending', NULL, 'Unpaid', NULL, '2025-06-22 15:46:38', NULL, NULL);

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `full_name` varchar(100) DEFAULT NULL,
  `username` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `phone_number` varchar(20) DEFAULT NULL,
  `role` enum('Super Admin','Cashier') DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `status` enum('Active','Inactive') DEFAULT 'Active',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `full_name`, `username`, `email`, `phone_number`, `role`, `password`, `status`, `created_at`) VALUES
(46, 'Disa', 'disa', 'disa@mailinator.com', '8768332332', 'Super Admin', '$2y$10$XZgc97F5pP3HCXAd30MDDeThviRf2S0MzUlKfmnOZiTlH1XSl2vvW', 'Active', '2025-06-20 19:41:05'),
(47, 'Nivia', 'nivia', 'nivia@mailinator.com', '8927332323', 'Cashier', '$2y$10$1z2uOMZFdY7bj4Z8JQyYP.cmubDLPYen40498d/gq8aAOI7n5zD.O', 'Active', '2025-06-20 23:23:03');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `delivery_orders`
--
ALTER TABLE `delivery_orders`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_pelanggan` (`id_pelanggan`);

--
-- Indeks untuk tabel `delivery_order_items`
--
ALTER TABLE `delivery_order_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `delivery_id` (`delivery_id`),
  ADD KEY `menu_id` (`menu_id`);

--
-- Indeks untuk tabel `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `menu_ingredients`
--
ALTER TABLE `menu_ingredients`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id_order`),
  ADD KEY `fk_orders_pelanggan` (`id_pelanggan`);

--
-- Indeks untuk tabel `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id_order_item`),
  ADD KEY `fk_orderitems_orders` (`id_order`),
  ADD KEY `fk_orderitems_menu` (`id_menu`);

--
-- Indeks untuk tabel `pelanggan`
--
ALTER TABLE `pelanggan`
  ADD PRIMARY KEY (`id_pelanggan`);

--
-- Indeks untuk tabel `table_reservations`
--
ALTER TABLE `table_reservations`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `delivery_orders`
--
ALTER TABLE `delivery_orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT untuk tabel `delivery_order_items`
--
ALTER TABLE `delivery_order_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT untuk tabel `menu`
--
ALTER TABLE `menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT untuk tabel `menu_ingredients`
--
ALTER TABLE `menu_ingredients`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=110;

--
-- AUTO_INCREMENT untuk tabel `orders`
--
ALTER TABLE `orders`
  MODIFY `id_order` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=101;

--
-- AUTO_INCREMENT untuk tabel `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id_order_item` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=283;

--
-- AUTO_INCREMENT untuk tabel `pelanggan`
--
ALTER TABLE `pelanggan`
  MODIFY `id_pelanggan` int(16) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT untuk tabel `table_reservations`
--
ALTER TABLE `table_reservations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=48;

--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `delivery_orders`
--
ALTER TABLE `delivery_orders`
  ADD CONSTRAINT `fk_delivery_pelanggan` FOREIGN KEY (`id_pelanggan`) REFERENCES `pelanggan` (`id_pelanggan`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `delivery_order_items`
--
ALTER TABLE `delivery_order_items`
  ADD CONSTRAINT `delivery_order_items_ibfk_1` FOREIGN KEY (`delivery_id`) REFERENCES `delivery_orders` (`id`),
  ADD CONSTRAINT `delivery_order_items_ibfk_2` FOREIGN KEY (`menu_id`) REFERENCES `menu` (`id`);

--
-- Ketidakleluasaan untuk tabel `orders`
--
ALTER TABLE `orders`
  ADD CONSTRAINT `fk_orders_pelanggan` FOREIGN KEY (`id_pelanggan`) REFERENCES `pelanggan` (`id_pelanggan`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Ketidakleluasaan untuk tabel `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `fk_orderitems_menu` FOREIGN KEY (`id_menu`) REFERENCES `menu` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_orderitems_orders` FOREIGN KEY (`id_order`) REFERENCES `orders` (`id_order`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
